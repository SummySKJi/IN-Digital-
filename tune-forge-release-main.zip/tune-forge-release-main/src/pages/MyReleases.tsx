
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { PlusCircle, Music2, FileMusic, Disc, Calendar, CheckCircle2, Info, X } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { supabase } from "@/integrations/supabase/client";
import { MusicSubmission } from '@/types/database';

const MyReleases = () => {
  const navigate = useNavigate();
  const [releases, setReleases] = useState<MusicSubmission[]>([]);
  const [loading, setLoading] = useState(true);
  
  useEffect(() => {
    fetchReleases();
  }, []);
  
  const fetchReleases = async () => {
    try {
      setLoading(true);
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.user?.id) return;
      
      const { data, error } = await supabase
        .from('music_submissions')
        .select('*')
        .eq('user_id', session.session.user.id)
        .order('submitted_date', { ascending: false });
      
      if (error) throw error;
      if (data) {
        setReleases(data as MusicSubmission[]);
      }
    } catch (error) {
      console.error('Error fetching releases:', error);
    } finally {
      setLoading(false);
    }
  };
  
  const getStatusBadge = (status: string) => {
    switch(status) {
      case 'pending':
        return <Badge variant="outline" className="bg-yellow-100 text-yellow-800 border-yellow-200">Under Review</Badge>;
      case 'approved':
        return <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">Approved</Badge>;
      case 'processing':
        return <Badge variant="outline" className="bg-blue-100 text-blue-800 border-blue-200">Processing</Badge>;
      case 'released':
        return <Badge variant="outline" className="bg-purple-100 text-purple-800 border-purple-200">Released</Badge>;
      case 'rejected':
        return <Badge variant="outline" className="bg-red-100 text-red-800 border-red-200">Rejected</Badge>;
      default:
        return <Badge variant="outline">{status}</Badge>;
    }
  };
  
  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">My Releases</h1>
          <p className="text-gray-500">Manage your music releases</p>
        </div>
        
        <Button 
          className="bg-music-600 hover:bg-music-700"
          onClick={() => navigate('/dashboard/upload')}
        >
          <PlusCircle className="mr-2 h-4 w-4" />
          New Release
        </Button>
      </div>

      {loading ? (
        <div className="text-center py-10">
          <svg className="animate-spin h-8 w-8 text-music-600 mx-auto" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
          </svg>
          <p className="mt-2 text-gray-500">Loading your releases...</p>
        </div>
      ) : releases.length === 0 ? (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Music2 className="mr-2 h-5 w-5 text-music-600" />
              Recent Releases
            </CardTitle>
            <CardDescription>Your recently uploaded music</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="text-center py-12">
              <Music2 className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-xl font-semibold text-gray-900">No releases yet</h3>
              <p className="mt-1 text-gray-500">Get started by creating a new release</p>
              <div className="mt-6">
                <Button 
                  className="bg-music-600 hover:bg-music-700"
                  onClick={() => navigate('/dashboard/upload')}
                >
                  <PlusCircle className="mr-2 h-4 w-4" />
                  New Release
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {releases.map((release) => (
            <Card key={release.id} className="overflow-hidden">
              <div className="flex flex-col sm:flex-row">
                <div className="w-full sm:w-40 h-40 bg-gray-100 relative flex-shrink-0">
                  {/* This would be the cover image in a real app */}
                  <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
                    <FileMusic className="h-16 w-16 text-gray-400" />
                  </div>
                </div>
                <div className="p-4 w-full">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-medium text-lg line-clamp-1">{release.song_name}</h3>
                      <p className="text-gray-600 text-sm line-clamp-1">{release.artist_name}</p>
                    </div>
                    <div>{getStatusBadge(release.status)}</div>
                  </div>
                  
                  <div className="mt-2 space-y-1">
                    <div className="flex items-center text-sm text-gray-500">
                      <Disc className="h-3.5 w-3.5 mr-1.5" />
                      <span>{release.type}</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-500">
                      <Calendar className="h-3.5 w-3.5 mr-1.5" />
                      <span>Submitted: {formatDate(release.submitted_date)}</span>
                    </div>
                    {release.label_name && (
                      <div className="text-sm text-gray-500 line-clamp-1">
                        Label: {release.label_name}
                      </div>
                    )}
                  </div>
                  
                  {release.status === 'rejected' && release.rejection_reason && (
                    <div className="mt-2 text-sm bg-red-50 p-2 rounded">
                      <div className="font-medium text-red-800 flex items-center">
                        <Info className="h-3.5 w-3.5 mr-1" />
                        Rejection reason:
                      </div>
                      <p className="text-red-700">{release.rejection_reason}</p>
                    </div>
                  )}
                  
                  {release.status === 'pending' && (
                    <div className="mt-3 flex">
                      <Button 
                        variant="outline" 
                        size="sm"
                        className="text-xs"
                        onClick={() => navigate(`/dashboard/releases/${release.id}`)}
                      >
                        View Details
                      </Button>
                    </div>
                  )}
                  
                  {release.status === 'released' && (
                    <div className="mt-3 flex">
                      <Button 
                        size="sm" 
                        className="text-xs bg-music-600 hover:bg-music-700"
                      >
                        <CheckCircle2 className="mr-1 h-3 w-3" />
                        View Analytics
                      </Button>
                    </div>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default MyReleases;
