
import React, { useEffect, useState } from 'react';
import ProgressSteps from '@/components/upload/ProgressSteps';
import UploadAudioFile from '@/components/upload/UploadAudioFile';
import UploadCoverArt from '@/components/upload/UploadCoverArt';
import BasicInformation from '@/components/upload/BasicInformation';
import CreditsMetadata from '@/components/upload/CreditsMetadata';
import PlatformSelection from '@/components/upload/PlatformSelection';
import ReleaseDate from '@/components/upload/ReleaseDate';
import TerritorySelection from '@/components/upload/TerritorySelection';
import ReleaseSummary from '@/components/upload/ReleaseSummary';
import FormNavigation from '@/components/upload/FormNavigation';
import { useUploadMusicForm } from '@/hooks/useUploadMusicForm';
import { supabase } from "@/integrations/supabase/client";
import { Artist, Label } from '@/types/database';

const UploadMusic = () => {
  const [artists, setArtists] = useState<Artist[]>([]);
  const [labels, setLabels] = useState<Label[]>([]);
  const {
    currentStep,
    uploadedFile,
    uploadProgress,
    coverImage,
    coverImageUrl,
    releaseDate,
    selectedPlatforms,
    isSubmitting,
    releaseInfo,
    setUploadedFile,
    setCoverImage,
    setCoverImageUrl,
    setReleaseDate,
    setSelectedPlatforms,
    handleChange,
    handleSelectChange,
    handleExplicitChange,
    nextStep,
    prevStep,
    handleSubmit
  } = useUploadMusicForm();

  useEffect(() => {
    fetchUserArtists();
    fetchUserLabels();
  }, []);

  const fetchUserArtists = async () => {
    try {
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.user?.id) return;
      
      const { data, error } = await supabase
        .from('artists')
        .select('*')
        .eq('user_id', session.session.user.id);
      
      if (error) throw error;
      if (data) setArtists(data);
    } catch (error) {
      console.error('Error fetching artists:', error);
    }
  };

  const fetchUserLabels = async () => {
    try {
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.user?.id) return;
      
      const { data, error } = await supabase
        .from('labels')
        .select('*')
        .eq('user_id', session.session.user.id);
      
      if (error) throw error;
      if (data) setLabels(data);
    } catch (error) {
      console.error('Error fetching labels:', error);
    }
  };

  const handleArtistChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const artistId = e.target.value;
    if (artistId) {
      const selectedArtist = artists.find(a => a.id === artistId);
      handleChange({
        target: {
          name: 'artistId',
          value: artistId
        }
      } as React.ChangeEvent<HTMLInputElement>);
      handleChange({
        target: {
          name: 'primaryArtist',
          value: selectedArtist?.name || ''
        }
      } as React.ChangeEvent<HTMLInputElement>);
      handleChange({
        target: {
          name: 'instagramId',
          value: selectedArtist?.instagram_id || ''
        }
      } as React.ChangeEvent<HTMLInputElement>);
    } else {
      handleChange({
        target: {
          name: 'artistId',
          value: ''
        }
      } as React.ChangeEvent<HTMLInputElement>);
      handleChange({
        target: {
          name: 'primaryArtist',
          value: ''
        }
      } as React.ChangeEvent<HTMLInputElement>);
      handleChange({
        target: {
          name: 'instagramId',
          value: ''
        }
      } as React.ChangeEvent<HTMLInputElement>);
    }
  };

  const handleLabelChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const labelId = e.target.value;
    if (labelId) {
      const selectedLabel = labels.find(l => l.id === labelId);
      handleChange({
        target: {
          name: 'labelId',
          value: labelId
        }
      } as React.ChangeEvent<HTMLInputElement>);
      handleChange({
        target: {
          name: 'label',
          value: selectedLabel?.name || ''
        }
      } as React.ChangeEvent<HTMLInputElement>);
    } else {
      handleChange({
        target: {
          name: 'labelId',
          value: ''
        }
      } as React.ChangeEvent<HTMLInputElement>);
      handleChange({
        target: {
          name: 'label',
          value: ''
        }
      } as React.ChangeEvent<HTMLInputElement>);
    }
  };

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Upload Music</h1>
      <ProgressSteps currentStep={currentStep} />

      {currentStep === 1 && (
        <div className="space-y-6">
          <UploadAudioFile
            uploadedFile={uploadedFile}
            setUploadedFile={setUploadedFile}
            uploadProgress={uploadProgress}
          />
          <UploadCoverArt
            coverImage={coverImage}
            coverImageUrl={coverImageUrl}
            setCoverImage={setCoverImage}
            setCoverImageUrl={setCoverImageUrl}
          />
          <FormNavigation
            currentStep={currentStep}
            onNext={nextStep}
            onPrev={prevStep}
            canProgress={!!uploadedFile && !!coverImage}
          />
        </div>
      )}

      {currentStep === 2 && (
        <div className="space-y-6">
          <BasicInformation
            releaseInfo={releaseInfo}
            handleChange={handleChange}
            handleSelectChange={handleSelectChange}
            handleExplicitChange={handleExplicitChange}
            handleArtistChange={handleArtistChange}
            handleLabelChange={handleLabelChange}
            handleReleaseTypeChange={(type) => handleChange({
              target: { name: 'releaseType', value: type }
            } as React.ChangeEvent<HTMLInputElement>)}
            artists={artists}
            labels={labels}
          />
          <CreditsMetadata
            releaseInfo={releaseInfo}
            handleChange={handleChange}
          />
          <FormNavigation
            currentStep={currentStep}
            onNext={nextStep}
            onPrev={prevStep}
            canProgress={!!releaseInfo.title && !!releaseInfo.primaryArtist && !!releaseInfo.genre && !!releaseInfo.language}
          />
        </div>
      )}

      {currentStep === 3 && (
        <div className="space-y-6">
          <PlatformSelection 
            selectedPlatforms={selectedPlatforms}
            setSelectedPlatforms={setSelectedPlatforms}
          />
          <ReleaseDate
            releaseDate={releaseDate}
            setReleaseDate={setReleaseDate}
          />
          <TerritorySelection />
          <ReleaseSummary
            releaseInfo={releaseInfo}
            coverImageUrl={coverImageUrl}
            selectedPlatforms={selectedPlatforms}
          />
          <FormNavigation
            currentStep={currentStep}
            onNext={nextStep}
            onPrev={prevStep}
            showSubmitButton
            isSubmitting={isSubmitting}
            onSubmit={handleSubmit}
            canProgress={true}
          />
        </div>
      )}
    </div>
  );
};

export default UploadMusic;

