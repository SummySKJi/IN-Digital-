import React, { useEffect, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { supabase } from '@/integrations/supabase/client';
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, ChevronDown, Search, Filter, Users, Music, DollarSign, Clock, AlertTriangle, CheckCircle2 } from 'lucide-react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Link } from 'react-router-dom';

const AdminDashboard = () => {
  const stats = [
    {
      title: "Total Users",
      value: "2,853",
      change: "+12.5%",
      icon: <Users className="h-7 w-7 text-blue-500" />
    },
    {
      title: "Active Releases",
      value: "14,391",
      change: "+23.1%",
      icon: <Music className="h-7 w-7 text-purple-500" />
    },
    {
      title: "Monthly Revenue",
      value: "$42,582",
      change: "+8.2%",
      icon: <DollarSign className="h-7 w-7 text-green-500" />
    },
    {
      title: "Pending Reviews",
      value: "38",
      change: "-4",
      icon: <Clock className="h-7 w-7 text-amber-500" />
    }
  ];

  const [pendingReleases, setPendingReleases] = useState<any[]>([]);
  const [loadingReleases, setLoadingReleases] = useState(false);

  useEffect(() => {
    const fetchReleases = async () => {
      setLoadingReleases(true);
      const { data, error } = await supabase
        .from("music_submissions")
        .select("*")
        .order("submitted_date", { ascending: false });
      if (!error) setPendingReleases(data || []);
      setLoadingReleases(false);
    };
    fetchReleases();
  }, []);

  const recentUsers = [
    {
      name: "Emma Thompson",
      email: "emma@example.com",
      joined: "Apr 12, 2023",
      plan: "Professional",
      status: "Active"
    },
    {
      name: "James Wilson",
      email: "james@example.com",
      joined: "Apr 11, 2023",
      plan: "Starter",
      status: "Active"
    },
    {
      name: "Liu Wei",
      email: "liu@example.com",
      joined: "Apr 10, 2023",
      plan: "Label",
      status: "Active"
    },
    {
      name: "Sophia Garcia",
      email: "sophia@example.com",
      joined: "Apr 9, 2023",
      plan: "Professional",
      status: "Inactive"
    }
  ];

  const alerts = [
    {
      type: "warning",
      message: "Suspicious streaming activity detected for user ID #3892",
      time: "2 hours ago"
    },
    {
      type: "info",
      message: "System maintenance scheduled for April 20, 2023",
      time: "1 day ago"
    },
    {
      type: "error",
      message: "Payment processing error for 3 users",
      time: "2 days ago"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-100">
      <header className="bg-gray-900 text-white px-6 py-4">
        <div className="container mx-auto flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <ShieldCheck className="h-6 w-6" />
            <h1 className="text-xl font-bold">TuneForge Admin</h1>
          </div>
          <div className="flex items-center space-x-4">
            <Link to="/" className="text-sm hover:underline">View Site</Link>
            <div className="relative">
              <button className="flex items-center space-x-2">
                <Avatar className="h-8 w-8">
                  <AvatarImage src="https://github.com/shadcn.png" />
                  <AvatarFallback>AD</AvatarFallback>
                </Avatar>
                <span className="text-sm">Admin</span>
                <ChevronDown className="h-4 w-4" />
              </button>
            </div>
          </div>
        </div>
      </header>
      
      <div className="container mx-auto px-6 py-8">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-8">
          <div>
            <h1 className="text-2xl font-bold text-gray-800">Admin Dashboard</h1>
            <p className="text-gray-600">Welcome back, Admin</p>
          </div>
          
          <div className="mt-4 md:mt-0 flex space-x-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input 
                placeholder="Search..." 
                className="pl-10 max-w-xs"
              />
            </div>
            <Button variant="outline" className="flex items-center">
              <Filter className="h-4 w-4 mr-2" />
              Filters
            </Button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {stats.map((stat, index) => (
            <Card key={index}>
              <CardContent className="p-6 flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-500 mb-1">{stat.title}</p>
                  <div className="flex items-center">
                    <h3 className="text-2xl font-bold mr-2">{stat.value}</h3>
                    <span className="text-xs font-medium text-green-500 bg-green-50 px-1.5 py-0.5 rounded">
                      {stat.change}
                    </span>
                  </div>
                </div>
                <div className="bg-gray-100 p-3 rounded-full">
                  {stat.icon}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          <Card className="col-span-1 lg:col-span-2">
            <CardHeader className="pb-2">
              <CardTitle>Pending Release Approvals</CardTitle>
            </CardHeader>
            <CardContent>
              {loadingReleases ? (
                <div className="p-8 text-center text-gray-500">Loading releases...</div>
              ) : (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left font-medium text-gray-500 pb-3">Release ID</th>
                        <th className="text-left font-medium text-gray-500 pb-3">Song Name</th>
                        <th className="text-left font-medium text-gray-500 pb-3">Artist</th>
                        <th className="text-left font-medium text-gray-500 pb-3">Submitted</th>
                        <th className="text-left font-medium text-gray-500 pb-3">Type</th>
                        <th className="text-left font-medium text-gray-500 pb-3">Status</th>
                        <th className="text-left font-medium text-gray-500 pb-3">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {pendingReleases.map((release) => (
                        <tr key={release.id} className="hover:bg-gray-50">
                          <td className="py-3 text-sm">{release.id}</td>
                          <td className="py-3 text-sm">{release.song_name}</td>
                          <td className="py-3 text-sm">{release.artist_name}</td>
                          <td className="py-3 text-sm text-gray-500">{new Date(release.submitted_date).toLocaleDateString()}</td>
                          <td className="py-3 text-sm">{release.type}</td>
                          <td className="py-3">
                            <Badge className={`text-xs px-2 py-1 rounded ${release.status === "pending" ? "bg-yellow-100 text-yellow-800" : "bg-green-100 text-green-800"}`}>
                              {release.status}
                            </Badge>
                          </td>
                          <td className="py-3">
                            <div className="flex space-x-2">
                              <Button size="sm" variant="default">Review</Button>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
              <div className="mt-4 text-center">
                <Button variant="outline" size="sm">View All Pending Releases</Button>
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="pb-2">
              <CardTitle>System Alerts</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {alerts.map((alert, index) => (
                  <div key={index} className="p-3 rounded-lg border flex items-start space-x-3">
                    <div className={`p-1.5 rounded-full ${
                      alert.type === 'warning' ? 'bg-yellow-100' : 
                      alert.type === 'error' ? 'bg-red-100' : 'bg-blue-100'
                    }`}>
                      {alert.type === 'warning' ? (
                        <AlertTriangle className={`h-4 w-4 text-yellow-600`} />
                      ) : alert.type === 'error' ? (
                        <AlertTriangle className={`h-4 w-4 text-red-600`} />
                      ) : (
                        <CheckCircle2 className={`h-4 w-4 text-blue-600`} />
                      )}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm">{alert.message}</p>
                      <p className="text-xs text-gray-500 mt-1">{alert.time}</p>
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="mt-4 text-center">
                <Button variant="outline" size="sm">View All Alerts</Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <Card>
          <CardHeader className="pb-2">
            <CardTitle>Recent Users</CardTitle>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="all">
              <TabsList className="mb-4">
                <TabsTrigger value="all">All Users</TabsTrigger>
                <TabsTrigger value="active">Active</TabsTrigger>
                <TabsTrigger value="pending">Pending</TabsTrigger>
                <TabsTrigger value="inactive">Inactive</TabsTrigger>
              </TabsList>
              
              <TabsContent value="all">
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead>
                      <tr className="border-b">
                        <th className="text-left font-medium text-gray-500 pb-3">Name</th>
                        <th className="text-left font-medium text-gray-500 pb-3">Email</th>
                        <th className="text-left font-medium text-gray-500 pb-3">Joined</th>
                        <th className="text-left font-medium text-gray-500 pb-3">Plan</th>
                        <th className="text-left font-medium text-gray-500 pb-3">Status</th>
                        <th className="text-left font-medium text-gray-500 pb-3">Action</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y">
                      {recentUsers.map((user, index) => (
                        <tr key={index} className="hover:bg-gray-50">
                          <td className="py-3">
                            <div className="flex items-center space-x-3">
                              <Avatar className="h-8 w-8">
                                <AvatarFallback>
                                  {user.name.split(' ').map(n => n[0]).join('')}
                                </AvatarFallback>
                              </Avatar>
                              <span className="font-medium text-sm">{user.name}</span>
                            </div>
                          </td>
                          <td className="py-3 text-sm">{user.email}</td>
                          <td className="py-3 text-sm text-gray-500">{user.joined}</td>
                          <td className="py-3">
                            <span className={`px-2 py-1 rounded text-xs ${
                              user.plan === 'Label' ? 'bg-purple-100 text-purple-700' :
                              user.plan === 'Professional' ? 'bg-blue-100 text-blue-700' :
                              'bg-gray-100 text-gray-700'
                            }`}>
                              {user.plan}
                            </span>
                          </td>
                          <td className="py-3">
                            <span className={`inline-flex items-center px-2 py-0.5 rounded text-xs font-medium ${
                              user.status === 'Active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'
                            }`}>
                              {user.status === 'Active' && (
                                <span className="h-1.5 w-1.5 rounded-full bg-green-600 mr-1.5"></span>
                              )}
                              {user.status}
                            </span>
                          </td>
                          <td className="py-3">
                            <Button size="sm" variant="outline">View</Button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
                
                <div className="mt-4 text-center">
                  <Button variant="outline" size="sm">View All Users</Button>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminDashboard;
