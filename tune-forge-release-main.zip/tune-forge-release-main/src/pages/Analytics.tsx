
import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Search, BarChart2, Download, Coins } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

const Analytics = () => {
  const [searchQuery, setSearchQuery] = useState('');
  
  const trackData = [
    {
      songName: "Summer Nights",
      isrc: "USRC12345678",
      spotify: 12453,
      appleMusic: 8765,
      ytMusic: 15678,
      jioSaavn: 4532,
      totalStreams: 41428
    },
    {
      songName: "Midnight Dreams",
      isrc: "USRC87654321",
      spotify: 9876,
      appleMusic: 7654,
      ytMusic: 12345,
      jioSaavn: 3210,
      totalStreams: 33085
    },
    {
      songName: "Ocean Waves",
      isrc: "USRC23456789",
      spotify: 8765,
      appleMusic: 5432,
      ytMusic: 9876,
      jioSaavn: 2109,
      totalStreams: 26182
    }
  ];

  const reports = [
    {
      title: "Q1 2023 Royalty Report",
      date: "Apr 15, 2023",
      type: "PDF",
      size: "1.2 MB"
    },
    {
      title: "Q4 2022 Royalty Report",
      date: "Jan 10, 2023",
      type: "XLSX",
      size: "0.9 MB"
    },
    {
      title: "Q3 2022 Royalty Report",
      date: "Oct 5, 2022",
      type: "CSV",
      size: "1.5 MB"
    }
  ];

  const chartData = [
    { name: 'Jan', spotify: 4000, appleMusic: 2400, ytMusic: 2400, jioSaavn: 1200 },
    { name: 'Feb', spotify: 5000, appleMusic: 3000, ytMusic: 3200, jioSaavn: 1600 },
    { name: 'Mar', spotify: 6000, appleMusic: 3500, ytMusic: 4000, jioSaavn: 2000 },
    { name: 'Apr', spotify: 7000, appleMusic: 4000, ytMusic: 4500, jioSaavn: 2200 },
    { name: 'May', spotify: 8000, appleMusic: 4500, ytMusic: 5000, jioSaavn: 2600 },
    { name: 'Jun', spotify: 9000, appleMusic: 5000, ytMusic: 5500, jioSaavn: 3000 },
  ];

  const filteredTracks = trackData.filter(track => 
    track.songName.toLowerCase().includes(searchQuery.toLowerCase()) || 
    track.isrc.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Analytics</h1>
        <p className="text-gray-500">Track your music performance across platforms</p>
      </div>

      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <div className="relative w-full max-w-sm">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search by song name or ISRC..."
            className="pl-10"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
          />
        </div>
        <div>
          <Button variant="outline" className="flex items-center gap-2">
            <Download size={16} />
            Export Data
          </Button>
        </div>
      </div>

      {/* Performance Chart */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart2 className="mr-2 h-5 w-5 text-music-600" />
            Performance Trends
          </CardTitle>
          <CardDescription>
            Monthly streaming performance across platforms
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="spotify" stroke="#1DB954" activeDot={{ r: 8 }} />
                <Line type="monotone" dataKey="appleMusic" stroke="#FC3C44" />
                <Line type="monotone" dataKey="ytMusic" stroke="#FF0000" />
                <Line type="monotone" dataKey="jioSaavn" stroke="#2196F3" />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Stream Analytics */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <BarChart2 className="mr-2 h-5 w-5 text-music-600" />
            Stream Analytics
          </CardTitle>
          <CardDescription>
            Performance metrics across streaming platforms
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4">Song</th>
                  <th className="text-left py-3 px-4">ISRC</th>
                  <th className="text-right py-3 px-4">Spotify</th>
                  <th className="text-right py-3 px-4">Apple Music</th>
                  <th className="text-right py-3 px-4">YT Music</th>
                  <th className="text-right py-3 px-4">JioSaavn</th>
                  <th className="text-right py-3 px-4">Total</th>
                </tr>
              </thead>
              <tbody>
                {filteredTracks.map((track, index) => (
                  <tr key={index} className="border-b">
                    <td className="py-3 px-4 font-medium">{track.songName}</td>
                    <td className="py-3 px-4 text-gray-500">{track.isrc}</td>
                    <td className="py-3 px-4 text-right">{track.spotify.toLocaleString()}</td>
                    <td className="py-3 px-4 text-right">{track.appleMusic.toLocaleString()}</td>
                    <td className="py-3 px-4 text-right">{track.ytMusic.toLocaleString()}</td>
                    <td className="py-3 px-4 text-right">{track.jioSaavn.toLocaleString()}</td>
                    <td className="py-3 px-4 text-right font-medium">{track.totalStreams.toLocaleString()}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>

      {/* Royalty Reports */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Coins className="mr-2 h-5 w-5 text-music-600" />
            Royalty Reports
          </CardTitle>
          <CardDescription>
            Download your earnings reports
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b">
                  <th className="text-left py-3 px-4">Report</th>
                  <th className="text-left py-3 px-4">Date</th>
                  <th className="text-left py-3 px-4">Type</th>
                  <th className="text-left py-3 px-4">Size</th>
                  <th className="text-right py-3 px-4">Action</th>
                </tr>
              </thead>
              <tbody>
                {reports.map((report, index) => (
                  <tr key={index} className="border-b">
                    <td className="py-3 px-4 font-medium">{report.title}</td>
                    <td className="py-3 px-4 text-gray-500">{report.date}</td>
                    <td className="py-3 px-4">
                      <span className={`inline-block px-2 py-1 text-xs rounded-full ${
                        report.type === "PDF" ? "bg-red-100 text-red-700" :
                        report.type === "XLSX" ? "bg-green-100 text-green-700" :
                        "bg-blue-100 text-blue-700"
                      }`}>
                        {report.type}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-gray-500">{report.size}</td>
                    <td className="py-3 px-4 text-right">
                      <Button variant="ghost" size="sm" className="text-music-600">
                        <Download size={16} className="mr-1" />
                        Download
                      </Button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Analytics;
