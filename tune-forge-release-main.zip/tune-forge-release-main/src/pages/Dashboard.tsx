
import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { 
  TrendingUp, 
  Calendar, 
  Music, 
  BarChart2, 
  DollarSign, 
  Globe, 
  Upload, 
  ArrowUpRight 
} from "lucide-react";
import { Link } from 'react-router-dom';

const Dashboard = () => {
  // Sample data for the dashboard
  const stats = [
    { 
      title: "Total Streams", 
      value: "245,691", 
      change: "+12.3%", 
      trend: "up",
      icon: <BarChart2 className="h-4 w-4 text-green-500" />
    },
    { 
      title: "Monthly Earnings", 
      value: "$1,245.32", 
      change: "+8.7%", 
      trend: "up",
      icon: <DollarSign className="h-4 w-4 text-green-500" />
    },
    { 
      title: "Total Releases", 
      value: "12", 
      change: "+2", 
      trend: "up",
      icon: <Music className="h-4 w-4 text-music-500" />
    },
    { 
      title: "Listeners", 
      value: "34,578", 
      change: "+5.2%", 
      trend: "up",
      icon: <Globe className="h-4 w-4 text-blue-500" />
    },
  ];

  const platformData = [
    { platform: "Spotify", streams: 124853, percentage: 50.8 },
    { platform: "Apple Music", streams: 68291, percentage: 27.8 },
    { platform: "YouTube Music", streams: 31940, percentage: 13.0 },
    { platform: "Amazon Music", streams: 12607, percentage: 5.1 },
    { platform: "Other Platforms", streams: 8000, percentage: 3.3 },
  ];

  const upcomingReleases = [
    {
      title: "Summer Nights EP",
      status: "Scheduled",
      date: "May 15, 2023",
      platforms: 8,
    },
    {
      title: "Rainfall (Single)",
      status: "In Review",
      date: "Pending Approval",
      platforms: 12,
    }
  ];

  const recentReleases = [
    {
      title: "Midnight Dreams",
      released: "Apr 2, 2023",
      streams: 24689,
      trend: "up",
      image: "https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&q=80"
    },
    {
      title: "Ocean Waves",
      released: "Mar 15, 2023",
      streams: 18456,
      trend: "up",
      image: "https://images.unsplash.com/photo-1493225457124-a3eb161ffa5f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&q=80"
    },
    {
      title: "City Lights",
      released: "Feb 28, 2023",
      streams: 32145,
      trend: "up",
      image: "https://images.unsplash.com/photo-1511671782779-c97d3d27a1d4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&q=80"
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold">Dashboard</h1>
          <p className="text-gray-500">Welcome back, John Doe</p>
        </div>
        <div className="mt-4 md:mt-0 flex space-x-3">
          <Link to="/dashboard/upload">
            <Button className="bg-music-600 hover:bg-music-700">
              <Upload className="h-4 w-4 mr-2" />
              Upload New Music
            </Button>
          </Link>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, index) => (
          <Card key={index}>
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-500">
                {stat.title}
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center">
                <div className="text-2xl font-bold">{stat.value}</div>
                <div className={`flex items-center text-xs ${
                  stat.trend === "up" ? "text-green-500" : "text-red-500"
                }`}>
                  {stat.icon}
                  <span className="ml-1">{stat.change}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Platform Distribution */}
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-xl">Platform Distribution</CardTitle>
            <CardDescription>
              Where your music is being streamed
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {platformData.map((platform, index) => (
                <div key={index}>
                  <div className="flex justify-between mb-1">
                    <span className="text-sm font-medium">{platform.platform}</span>
                    <span className="text-sm font-medium">{platform.streams.toLocaleString()}</span>
                  </div>
                  <Progress value={platform.percentage} className="h-2" />
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Releases */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-xl">Upcoming</CardTitle>
              <CardDescription>Your upcoming releases</CardDescription>
            </div>
            <Calendar className="h-4 w-4 text-gray-500" />
          </CardHeader>
          <CardContent>
            {upcomingReleases.length > 0 ? (
              <div className="space-y-4">
                {upcomingReleases.map((release, index) => (
                  <div key={index} className="border rounded-lg p-3">
                    <div className="flex justify-between">
                      <h3 className="font-medium">{release.title}</h3>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${
                        release.status === "Scheduled" 
                          ? "bg-green-100 text-green-800" 
                          : "bg-yellow-100 text-yellow-800"
                      }`}>
                        {release.status}
                      </span>
                    </div>
                    <div className="mt-2 flex items-center justify-between">
                      <div className="text-sm text-gray-500">{release.date}</div>
                      <div className="text-xs text-gray-500">{release.platforms} platforms</div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="flex flex-col items-center justify-center py-6 text-center">
                <Calendar className="h-10 w-10 text-gray-400 mb-3" />
                <p className="text-gray-500 mb-2">No upcoming releases</p>
                <Link to="/dashboard/upload">
                  <Button size="sm" variant="outline">
                    Schedule a Release
                  </Button>
                </Link>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Releases */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle className="text-xl">Recent Releases</CardTitle>
            <CardDescription>Performance of your latest music</CardDescription>
          </div>
          <Link to="/dashboard/catalog" className="text-sm text-music-600 hover:underline flex items-center">
            View all 
            <ArrowUpRight className="h-3 w-3 ml-1" />
          </Link>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {recentReleases.map((release, index) => (
              <div key={index} className="bg-gray-50 rounded-lg p-4 relative overflow-hidden">
                <div className="flex items-center space-x-3">
                  <div className="h-12 w-12 rounded-md overflow-hidden bg-gray-200">
                    <img 
                      src={release.image} 
                      alt={release.title} 
                      className="h-full w-full object-cover"
                    />
                  </div>
                  <div>
                    <h3 className="font-medium">{release.title}</h3>
                    <p className="text-xs text-gray-500">Released {release.released}</p>
                  </div>
                </div>
                <div className="mt-4">
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-gray-500">Total Streams</span>
                    <div className={`flex items-center ${
                      release.trend === "up" ? "text-green-500" : "text-red-500"
                    }`}>
                      <TrendingUp className="h-3 w-3 mr-1" />
                      <span className="text-xs font-medium">+18%</span>
                    </div>
                  </div>
                  <div className="text-lg font-bold mt-1">{release.streams.toLocaleString()}</div>
                </div>
                <div className="absolute bottom-0 right-0 h-16 w-16 opacity-10">
                  <Music className="h-full w-full" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
