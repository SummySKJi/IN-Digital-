
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { ArrowLeft, ShieldAlert, Mail, Lock } from 'lucide-react';
import { toast } from "sonner";
import { useNavigate } from 'react-router-dom';

const AdminLogin = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const navigate = useNavigate();

  const handleAdminLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      
      // Check for admin credentials - Admin@mdi.in / 11111111
      if (email === 'Admin@mdi.in' && password === '11111111') {
        toast.success('Admin login successful!');
        navigate('/admin-dashboard');
      } else {
        toast.error('Invalid admin credentials');
      }
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gray-900 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="text-center">
          <Link to="/" className="inline-block">
            <span className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-music-400 to-music-600">
              TuneForge
            </span>
          </Link>
          <div className="flex items-center justify-center mt-6">
            <ShieldAlert className="h-8 w-8 text-music-400" />
            <h2 className="ml-2 text-3xl font-bold text-white">Admin Login</h2>
          </div>
          <p className="mt-2 text-sm text-gray-400">
            Access the administration dashboard
          </p>
        </div>

        <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
          <div className="bg-gray-800 py-8 px-4 shadow sm:rounded-lg sm:px-10">
            <form className="space-y-6" onSubmit={handleAdminLogin}>
              <div>
                <Label htmlFor="email" className="text-gray-200">Email address</Label>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Mail className="h-5 w-5 text-gray-500" />
                  </div>
                  <Input
                    id="email"
                    name="email"
                    type="email"
                    autoComplete="email"
                    required
                    className="pl-10 bg-gray-700 border-gray-600 text-white"
                    placeholder="admin@example.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between">
                  <Label htmlFor="password" className="text-gray-200">Password</Label>
                  <Link to="/admin-forgot-password" className="text-sm font-medium text-music-400 hover:text-music-300">
                    Forgot password?
                  </Link>
                </div>
                <div className="mt-1 relative rounded-md shadow-sm">
                  <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                    <Lock className="h-5 w-5 text-gray-500" />
                  </div>
                  <Input
                    id="password"
                    name="password"
                    type="password"
                    autoComplete="current-password"
                    required
                    className="pl-10 bg-gray-700 border-gray-600 text-white"
                    placeholder="••••••••"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <Button
                  type="submit"
                  className="w-full bg-music-600 hover:bg-music-700"
                  disabled={isLoading}
                >
                  {isLoading ? 'Signing in...' : 'Sign in to Admin'}
                </Button>
              </div>
            </form>
            
            <div className="mt-4 text-center text-sm text-gray-400">
              <p>Default admin credentials:</p>
              <p>Email: Admin@mdi.in</p>
              <p>Password: 11111111</p>
            </div>
          </div>
        </div>

        <div className="mt-8 text-center">
          <Link to="/" className="inline-flex items-center text-sm text-gray-400 hover:text-music-400">
            <ArrowLeft className="mr-2 h-4 w-4" />
            Back to homepage
          </Link>
        </div>
      </div>
    </div>
  );
};

export default AdminLogin;
