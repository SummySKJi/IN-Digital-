
import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { toast } from "sonner";
import { ArrowLeft, Music, Image, FileText, CheckSquare, XSquare, AlertTriangle } from 'lucide-react';
import { supabase } from "@/integrations/supabase/client";

const AdminReleaseReview = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [release, setRelease] = useState<any | null>(null);
  const [loading, setLoading] = useState(true);
  const [rejectionReason, setRejectionReason] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  useEffect(() => {
    if (id) {
      fetchReleaseDetails(id);
    }
  }, [id]);
  
  const fetchReleaseDetails = async (releaseId: string) => {
    try {
      setLoading(true);
      
      const { data, error } = await supabase
        .from('music_submissions')
        .select('*')
        .eq('id', releaseId)
        .single();
        
      if (error) throw error;
      
      if (data) {
        setRelease(data);
      }
    } catch (error) {
      console.error('Error fetching release details:', error);
      toast.error('Failed to load release details');
    } finally {
      setLoading(false);
    }
  };
  
  const handleApproveRelease = async () => {
    if (!release) return;
    
    setIsSubmitting(true);
    
    try {
      // Update the release status to "processing"
      const { error } = await supabase
        .from('music_submissions')
        .update({ status: 'processing' })
        .eq('id', release.id);
        
      if (error) throw error;
      
      toast.success('Release has been approved and moved to processing');
      navigate('/admin-dashboard');
    } catch (error) {
      console.error('Error approving release:', error);
      toast.error('Failed to approve release');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  const handleRejectRelease = async () => {
    if (!release) return;
    
    if (!rejectionReason) {
      toast.error('Please provide a reason for rejection');
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      // Update the release status to "rejected" with rejection reason
      const { error } = await supabase
        .from('music_submissions')
        .update({ 
          status: 'rejected',
          rejection_reason: rejectionReason 
        })
        .eq('id', release.id);
        
      if (error) throw error;
      
      toast.success('Release has been rejected');
      navigate('/admin-dashboard');
    } catch (error) {
      console.error('Error rejecting release:', error);
      toast.error('Failed to reject release');
    } finally {
      setIsSubmitting(false);
    }
  };
  
  if (loading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-music-600"></div>
      </div>
    );
  }
  
  if (!release) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <AlertTriangle className="h-12 w-12 text-red-500 mb-4" />
        <h2 className="text-xl font-bold mb-2">Release Not Found</h2>
        <p className="text-gray-500 mb-6">The release you're looking for doesn't exist or has been removed.</p>
        <Button onClick={() => navigate('/admin-dashboard')}>
          <ArrowLeft className="mr-2 h-4 w-4" />
          Back to Dashboard
        </Button>
      </div>
    );
  }
  
  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center mb-6">
        <Button variant="ghost" onClick={() => navigate('/admin-dashboard')} className="mr-4">
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back
        </Button>
        <div>
          <h1 className="text-2xl font-bold">Review Release</h1>
          <p className="text-gray-500">Review and approve or reject this music submission</p>
        </div>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Release Overview</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="aspect-square relative overflow-hidden bg-gray-100 rounded-md flex items-center justify-center">
                <Image className="h-12 w-12 text-gray-400" />
                <div className="absolute bottom-0 left-0 right-0 bg-black bg-opacity-50 text-white p-2">
                  Cover Art
                </div>
              </div>
              
              <div>
                <h3 className="text-lg font-bold">{release.song_name}</h3>
                <p className="text-gray-500">{release.artist_name}</p>
              </div>
              
              <div className="pt-4 border-t">
                <div className="grid grid-cols-2 gap-2">
                  <div>
                    <p className="text-xs text-gray-500">Type</p>
                    <p className="font-medium">{release.release_type || 'Single'}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Language</p>
                    <p className="font-medium">{release.song_language}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Label</p>
                    <p className="font-medium">{release.label_name || 'Independent'}</p>
                  </div>
                  <div>
                    <p className="text-xs text-gray-500">Submitted</p>
                    <p className="font-medium">{new Date(release.submitted_date).toLocaleDateString()}</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="mt-6">
            <CardHeader>
              <CardTitle className="flex items-center">
                <Music className="mr-2 h-5 w-5 text-gray-500" />
                Audio File
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <p className="text-sm font-medium">{release.audio_file_name}</p>
              <p className="text-xs text-gray-500">{release.file_size}</p>
              
              <div className="mt-4">
                <Button className="w-full">
                  Play Audio
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
        
        <div className="md:col-span-2">
          <Card className="mb-6">
            <CardHeader>
              <CardTitle>Release Details</CardTitle>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="metadata">
                <TabsList className="grid w-full grid-cols-3">
                  <TabsTrigger value="metadata">Metadata</TabsTrigger>
                  <TabsTrigger value="credits">Credits & Rights</TabsTrigger>
                  <TabsTrigger value="platforms">Distribution</TabsTrigger>
                </TabsList>
                
                <TabsContent value="metadata" className="space-y-4 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-xs text-gray-500">Song Title</Label>
                      <p className="font-medium">{release.song_name}</p>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-gray-500">Primary Artist</Label>
                      <p className="font-medium">{release.artist_name}</p>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-gray-500">Language</Label>
                      <p className="font-medium">{release.song_language}</p>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-gray-500">Release Type</Label>
                      <p className="font-medium">{release.release_type || 'Single'}</p>
                    </div>
                    
                    <div className="col-span-2">
                      <Label className="text-xs text-gray-500">Featured Artists</Label>
                      <p className="font-medium">{release.featured_artists || 'None'}</p>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="credits" className="space-y-4 pt-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <Label className="text-xs text-gray-500">Lyricists</Label>
                      <p className="font-medium">{release.lyricists || 'N/A'}</p>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-gray-500">Music Producer</Label>
                      <p className="font-medium">{release.music_producer || 'N/A'}</p>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-gray-500">Copyright</Label>
                      <p className="font-medium">{release.copyright || 'N/A'}</p>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-gray-500">Publisher</Label>
                      <p className="font-medium">{release.publisher || 'N/A'}</p>
                    </div>
                    
                    <div>
                      <Label className="text-xs text-gray-500">Label</Label>
                      <p className="font-medium">{release.label_name || 'Independent'}</p>
                    </div>
                  </div>
                </TabsContent>
                
                <TabsContent value="platforms" className="space-y-4 pt-4">
                  <div>
                    <Label className="text-xs text-gray-500">Selected Platforms</Label>
                    <div className="grid grid-cols-2 gap-2 mt-2">
                      {release.platforms && release.platforms.length > 0 ? (
                        release.platforms.map((platform: string) => (
                          <div key={platform} className="flex items-center">
                            <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                            <p className="text-sm">{platform}</p>
                          </div>
                        ))
                      ) : (
                        <p className="text-sm text-gray-500">Default distribution to all platforms</p>
                      )}
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Review Decision</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <Label htmlFor="rejection-reason">Rejection Reason (if applicable)</Label>
                  <Textarea
                    id="rejection-reason"
                    placeholder="Provide a reason if you're rejecting this release..."
                    rows={4}
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                  />
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between border-t pt-4">
              <Button 
                variant="outline" 
                className="border-red-500 text-red-500 hover:bg-red-50"
                onClick={handleRejectRelease}
                disabled={isSubmitting}
              >
                <XSquare className="mr-2 h-4 w-4" />
                {isSubmitting ? 'Processing...' : 'Reject Release'}
              </Button>
              
              <Button 
                className="bg-green-600 hover:bg-green-700"
                onClick={handleApproveRelease}
                disabled={isSubmitting}
              >
                <CheckSquare className="mr-2 h-4 w-4" />
                {isSubmitting ? 'Processing...' : 'Approve Release'}
              </Button>
            </CardFooter>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AdminReleaseReview;
