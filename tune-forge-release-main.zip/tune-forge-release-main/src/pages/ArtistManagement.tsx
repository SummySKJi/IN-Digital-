
import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Artist, Label as LabelType } from "@/types/database";
import { toast } from "@/components/ui/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { Check, X, Plus, Edit, Trash } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const ArtistManagement = () => {
  // State for artist form
  const [artistForm, setArtistForm] = useState<Partial<Artist>>({
    name: '',
    email: '',
    phone: '',
    whatsapp: '',
    website: '',
    gender: 'male',
    youtube_channel: '',
    instagram_id: '',
    facebook_page: '',
    bio: '',
    spotify_profile: '',
    apple_music_profile: '',
    country: 'India',
    genres: [],
    languages: [],
  });

  // State for label form
  const [labelForm, setLabelForm] = useState<Partial<LabelType>>({
    name: '',
    email: '',
    phone: '',
    whatsapp: '',
    website: '',
    youtube_channel: '',
    instagram_id: '',
    facebook_page: '',
    bio: '',
    country: 'India',
    genres: [],
    languages: [],
  });

  // State for artists and labels
  const [artists, setArtists] = useState<Artist[]>([]);
  const [labels, setLabels] = useState<LabelType[]>([]);
  const [loading, setLoading] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentItemId, setCurrentItemId] = useState<string | null>(null);

  // Language options
  const languageOptions = [
    "Hindi", "English", "Punjabi", "Tamil", "Telugu", "Malayalam", 
    "Kannada", "Bengali", "Marathi", "Gujarati", "Odia", "Assamese",
    "Rajasthani", "Haryanvi", "Bhojpuri", "Urdu"
  ];

  // Genre options
  const genreOptions = [
    "Pop", "Rock", "Hip-Hop", "R&B", "Electronic", "Classical",
    "Jazz", "Country", "Folk", "Indie", "Bollywood", "Devotional",
    "Sufi", "Fusion", "Metal", "Punk", "Blues", "Reggae"
  ];

  // Load artists and labels on component mount
  useEffect(() => {
    fetchArtistsAndLabels();
  }, []);

  // Fetch artists and labels from Supabase
  const fetchArtistsAndLabels = async () => {
    setLoading(true);
    
    try {
      const { data: artistData, error: artistError } = await supabase
        .from('artists')
        .select('*');
        
      if (artistError) throw artistError;
      setArtists(artistData || []);
      
      const { data: labelData, error: labelError } = await supabase
        .from('labels')
        .select('*');
        
      if (labelError) throw labelError;
      setLabels(labelData || []);
    } catch (error) {
      console.error('Error fetching data:', error);
      toast({
        title: "Error",
        description: "Failed to load data. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Handle input change for artist form
  const handleArtistInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setArtistForm({ ...artistForm, [name]: value });
  };

  // Handle select change for artist form
  const handleArtistSelectChange = (name: string, value: string) => {
    setArtistForm({ ...artistForm, [name]: value });
  };

  // Handle multi-select change for artist form
  const handleArtistMultiSelectChange = (name: string, value: string) => {
    setArtistForm(prev => {
      const currentValues = prev[name as keyof typeof prev] as string[] || [];
      
      if (currentValues.includes(value)) {
        return { 
          ...prev, 
          [name]: currentValues.filter(item => item !== value) 
        };
      } else {
        return { 
          ...prev, 
          [name]: [...currentValues, value] 
        };
      }
    });
  };

  // Handle input change for label form
  const handleLabelInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setLabelForm({ ...labelForm, [name]: value });
  };

  // Handle select change for label form
  const handleLabelSelectChange = (name: string, value: string) => {
    setLabelForm({ ...labelForm, [name]: value });
  };

  // Handle multi-select change for label form
  const handleLabelMultiSelectChange = (name: string, value: string) => {
    setLabelForm(prev => {
      const currentValues = prev[name as keyof typeof prev] as string[] || [];
      
      if (currentValues.includes(value)) {
        return { 
          ...prev, 
          [name]: currentValues.filter(item => item !== value) 
        };
      } else {
        return { 
          ...prev, 
          [name]: [...currentValues, value] 
        };
      }
    });
  };

  // Submit artist form
  const handleArtistSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // Validate required fields
      const requiredFields = ['name', 'email', 'phone', 'gender'];
      for (const field of requiredFields) {
        if (!artistForm[field as keyof typeof artistForm]) {
          throw new Error(`${field.charAt(0).toUpperCase() + field.slice(1)} is required`);
        }
      }
      
      // Add user_id (in a real app, this would come from auth context)
      const formData = {
        ...artistForm,
        user_id: '00000000-0000-0000-0000-000000000000', // Placeholder - replace with actual user_id from auth
        genres: artistForm.genres || [],
        languages: artistForm.languages || []
      };
      
      if (isEditing && currentItemId) {
        // Update existing artist
        const { error } = await supabase
          .from('artists')
          .update(formData)
          .eq('id', currentItemId);
          
        if (error) throw error;
        toast({
          title: "Success",
          description: "Artist updated successfully",
        });
      } else {
        // Create new artist
        const { error } = await supabase
          .from('artists')
          .insert(formData);
          
        if (error) throw error;
        toast({
          title: "Success",
          description: "Artist created successfully",
        });
      }
      
      // Reset form and refetch data
      setArtistForm({
        name: '',
        email: '',
        phone: '',
        whatsapp: '',
        website: '',
        gender: 'male',
        youtube_channel: '',
        instagram_id: '',
        facebook_page: '',
        bio: '',
        spotify_profile: '',
        apple_music_profile: '',
        country: 'India',
        genres: [],
        languages: [],
      });
      setIsEditing(false);
      setCurrentItemId(null);
      fetchArtistsAndLabels();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to save artist. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Submit label form
  const handleLabelSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    try {
      // Validate required fields
      if (!labelForm.name) {
        throw new Error('Label name is required');
      }
      
      // Add user_id (in a real app, this would come from auth context)
      const formData = {
        ...labelForm,
        user_id: '00000000-0000-0000-0000-000000000000', // Placeholder - replace with actual user_id from auth
        genres: labelForm.genres || [],
        languages: labelForm.languages || []
      };
      
      if (isEditing && currentItemId) {
        // Update existing label
        const { error } = await supabase
          .from('labels')
          .update(formData)
          .eq('id', currentItemId);
          
        if (error) throw error;
        toast({
          title: "Success",
          description: "Label updated successfully",
        });
      } else {
        // Create new label
        const { error } = await supabase
          .from('labels')
          .insert(formData);
          
        if (error) throw error;
        toast({
          title: "Success",
          description: "Label created successfully",
        });
      }
      
      // Reset form and refetch data
      setLabelForm({
        name: '',
        email: '',
        phone: '',
        whatsapp: '',
        website: '',
        youtube_channel: '',
        instagram_id: '',
        facebook_page: '',
        bio: '',
        country: 'India',
        genres: [],
        languages: [],
      });
      setIsEditing(false);
      setCurrentItemId(null);
      fetchArtistsAndLabels();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to save label. Please try again.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Edit artist
  const editArtist = (artist: Artist) => {
    setArtistForm(artist);
    setIsEditing(true);
    setCurrentItemId(artist.id);
  };

  // Edit label
  const editLabel = (label: LabelType) => {
    setLabelForm(label);
    setIsEditing(true);
    setCurrentItemId(label.id);
  };

  // Delete artist
  const deleteArtist = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this artist?')) {
      try {
        const { error } = await supabase
          .from('artists')
          .delete()
          .eq('id', id);
          
        if (error) throw error;
        toast({
          title: "Success",
          description: "Artist deleted successfully",
        });
        fetchArtistsAndLabels();
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to delete artist. Please try again.",
          variant: "destructive"
        });
      }
    }
  };

  // Delete label
  const deleteLabel = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this label?')) {
      try {
        const { error } = await supabase
          .from('labels')
          .delete()
          .eq('id', id);
          
        if (error) throw error;
        toast({
          title: "Success",
          description: "Label deleted successfully",
        });
        fetchArtistsAndLabels();
      } catch (error) {
        toast({
          title: "Error",
          description: "Failed to delete label. Please try again.",
          variant: "destructive"
        });
      }
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold">Artist & Label Management</h1>
      </div>
      
      <Tabs defaultValue="artists" className="space-y-4">
        <TabsList className="grid w-full md:w-auto grid-cols-2">
          <TabsTrigger value="artists">Artists</TabsTrigger>
          <TabsTrigger value="labels">Labels</TabsTrigger>
        </TabsList>
        
        <TabsContent value="artists" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{isEditing ? 'Edit Artist' : 'Add New Artist'}</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleArtistSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="name" className="text-sm font-medium">Artist Name *</label>
                    <Input
                      id="name"
                      name="name"
                      value={artistForm.name || ''}
                      onChange={handleArtistInputChange}
                      placeholder="Enter artist name"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="email" className="text-sm font-medium">Email ID *</label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={artistForm.email || ''}
                      onChange={handleArtistInputChange}
                      placeholder="Enter email address"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="phone" className="text-sm font-medium">Phone Number *</label>
                    <Input
                      id="phone"
                      name="phone"
                      value={artistForm.phone || ''}
                      onChange={handleArtistInputChange}
                      placeholder="Enter phone number"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="whatsapp" className="text-sm font-medium">WhatsApp Number</label>
                    <Input
                      id="whatsapp"
                      name="whatsapp"
                      value={artistForm.whatsapp || ''}
                      onChange={handleArtistInputChange}
                      placeholder="Enter WhatsApp number"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="website" className="text-sm font-medium">Website</label>
                    <Input
                      id="website"
                      name="website"
                      value={artistForm.website || ''}
                      onChange={handleArtistInputChange}
                      placeholder="Enter website URL"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="gender" className="text-sm font-medium">Gender *</label>
                    <Select
                      value={artistForm.gender || 'male'}
                      onValueChange={(value) => handleArtistSelectChange('gender', value)}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select gender" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="youtube_channel" className="text-sm font-medium">YouTube Channel</label>
                    <Input
                      id="youtube_channel"
                      name="youtube_channel"
                      value={artistForm.youtube_channel || ''}
                      onChange={handleArtistInputChange}
                      placeholder="Enter YouTube channel URL"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="instagram_id" className="text-sm font-medium">Instagram ID *</label>
                    <Input
                      id="instagram_id"
                      name="instagram_id"
                      value={artistForm.instagram_id || ''}
                      onChange={handleArtistInputChange}
                      placeholder="Enter Instagram ID"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="facebook_page" className="text-sm font-medium">Facebook Page Link *</label>
                    <Input
                      id="facebook_page"
                      name="facebook_page"
                      value={artistForm.facebook_page || ''}
                      onChange={handleArtistInputChange}
                      placeholder="Enter Facebook page URL"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="spotify_profile" className="text-sm font-medium">Spotify Profile</label>
                    <Input
                      id="spotify_profile"
                      name="spotify_profile"
                      value={artistForm.spotify_profile || ''}
                      onChange={handleArtistInputChange}
                      placeholder="Enter Spotify profile URL"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="apple_music_profile" className="text-sm font-medium">Apple Music Profile</label>
                    <Input
                      id="apple_music_profile"
                      name="apple_music_profile"
                      value={artistForm.apple_music_profile || ''}
                      onChange={handleArtistInputChange}
                      placeholder="Enter Apple Music profile URL"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="country" className="text-sm font-medium">Country *</label>
                    <Input
                      id="country"
                      name="country"
                      value={artistForm.country || ''}
                      onChange={handleArtistInputChange}
                      placeholder="Enter country"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="bio" className="text-sm font-medium">Bio</label>
                  <Textarea
                    id="bio"
                    name="bio"
                    value={artistForm.bio || ''}
                    onChange={handleArtistInputChange}
                    placeholder="Enter artist bio"
                    rows={4}
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Genres</label>
                  <div className="flex flex-wrap gap-2">
                    {genreOptions.map((genre) => (
                      <Button
                        key={genre}
                        type="button"
                        variant={artistForm.genres?.includes(genre) ? "default" : "outline"}
                        size="sm"
                        onClick={() => handleArtistMultiSelectChange('genres', genre)}
                      >
                        {genre}
                      </Button>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Language of Songs</label>
                  <div className="flex flex-wrap gap-2">
                    {languageOptions.map((language) => (
                      <Button
                        key={language}
                        type="button"
                        variant={artistForm.languages?.includes(language) ? "default" : "outline"}
                        size="sm"
                        onClick={() => handleArtistMultiSelectChange('languages', language)}
                      >
                        {language}
                      </Button>
                    ))}
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button type="submit" disabled={loading}>
                    {isEditing ? 'Update Artist' : 'Add Artist'}
                  </Button>
                  {isEditing && (
                    <Button type="button" variant="outline" onClick={() => {
                      setIsEditing(false);
                      setCurrentItemId(null);
                      setArtistForm({
                        name: '',
                        email: '',
                        phone: '',
                        whatsapp: '',
                        website: '',
                        gender: 'male',
                        youtube_channel: '',
                        instagram_id: '',
                        facebook_page: '',
                        bio: '',
                        spotify_profile: '',
                        apple_music_profile: '',
                        country: 'India',
                        genres: [],
                        languages: [],
                      });
                    }}>
                      Cancel
                    </Button>
                  )}
                </div>
              </form>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Your Artists</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2">Name</th>
                      <th className="text-left py-2">Email</th>
                      <th className="text-left py-2">Phone</th>
                      <th className="text-left py-2">Country</th>
                      <th className="text-right py-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {artists.length === 0 ? (
                      <tr>
                        <td colSpan={5} className="py-4 text-center text-gray-500">
                          No artists found. Add your first artist above.
                        </td>
                      </tr>
                    ) : (
                      artists.map((artist) => (
                        <tr key={artist.id} className="border-b">
                          <td className="py-3">
                            <div className="flex items-center">
                              <Avatar className="h-8 w-8 mr-2">
                                <AvatarFallback>{artist.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              {artist.name}
                            </div>
                          </td>
                          <td className="py-3">{artist.email}</td>
                          <td className="py-3">{artist.phone}</td>
                          <td className="py-3">{artist.country}</td>
                          <td className="py-3 text-right space-x-2">
                            <Button variant="ghost" size="sm" onClick={() => editArtist(artist)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => deleteArtist(artist.id)}>
                              <Trash className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="labels" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{isEditing ? 'Edit Label' : 'Add New Label'}</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLabelSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label htmlFor="label_name" className="text-sm font-medium">Label Name *</label>
                    <Input
                      id="label_name"
                      name="name"
                      value={labelForm.name || ''}
                      onChange={handleLabelInputChange}
                      placeholder="Enter label name"
                      required
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="label_email" className="text-sm font-medium">Email ID</label>
                    <Input
                      id="label_email"
                      name="email"
                      type="email"
                      value={labelForm.email || ''}
                      onChange={handleLabelInputChange}
                      placeholder="Enter email address"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="label_phone" className="text-sm font-medium">Phone Number</label>
                    <Input
                      id="label_phone"
                      name="phone"
                      value={labelForm.phone || ''}
                      onChange={handleLabelInputChange}
                      placeholder="Enter phone number"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="label_whatsapp" className="text-sm font-medium">WhatsApp Number</label>
                    <Input
                      id="label_whatsapp"
                      name="whatsapp"
                      value={labelForm.whatsapp || ''}
                      onChange={handleLabelInputChange}
                      placeholder="Enter WhatsApp number"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="label_website" className="text-sm font-medium">Website</label>
                    <Input
                      id="label_website"
                      name="website"
                      value={labelForm.website || ''}
                      onChange={handleLabelInputChange}
                      placeholder="Enter website URL"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="label_youtube" className="text-sm font-medium">YouTube Channel</label>
                    <Input
                      id="label_youtube"
                      name="youtube_channel"
                      value={labelForm.youtube_channel || ''}
                      onChange={handleLabelInputChange}
                      placeholder="Enter YouTube channel URL"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="label_instagram" className="text-sm font-medium">Instagram ID *</label>
                    <Input
                      id="label_instagram"
                      name="instagram_id"
                      value={labelForm.instagram_id || ''}
                      onChange={handleLabelInputChange}
                      placeholder="Enter Instagram ID"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="label_facebook" className="text-sm font-medium">Facebook Page Link *</label>
                    <Input
                      id="label_facebook"
                      name="facebook_page"
                      value={labelForm.facebook_page || ''}
                      onChange={handleLabelInputChange}
                      placeholder="Enter Facebook page URL"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label htmlFor="label_country" className="text-sm font-medium">Country *</label>
                    <Input
                      id="label_country"
                      name="country"
                      value={labelForm.country || ''}
                      onChange={handleLabelInputChange}
                      placeholder="Enter country"
                      required
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label htmlFor="label_bio" className="text-sm font-medium">Bio</label>
                  <Textarea
                    id="label_bio"
                    name="bio"
                    value={labelForm.bio || ''}
                    onChange={handleLabelInputChange}
                    placeholder="Enter label bio"
                    rows={4}
                  />
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Genres</label>
                  <div className="flex flex-wrap gap-2">
                    {genreOptions.map((genre) => (
                      <Button
                        key={genre}
                        type="button"
                        variant={labelForm.genres?.includes(genre) ? "default" : "outline"}
                        size="sm"
                        onClick={() => handleLabelMultiSelectChange('genres', genre)}
                      >
                        {genre}
                      </Button>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Language of Songs</label>
                  <div className="flex flex-wrap gap-2">
                    {languageOptions.map((language) => (
                      <Button
                        key={language}
                        type="button"
                        variant={labelForm.languages?.includes(language) ? "default" : "outline"}
                        size="sm"
                        onClick={() => handleLabelMultiSelectChange('languages', language)}
                      >
                        {language}
                      </Button>
                    ))}
                  </div>
                </div>
                
                <div className="flex gap-2">
                  <Button type="submit" disabled={loading}>
                    {isEditing ? 'Update Label' : 'Add Label'}
                  </Button>
                  {isEditing && (
                    <Button type="button" variant="outline" onClick={() => {
                      setIsEditing(false);
                      setCurrentItemId(null);
                      setLabelForm({
                        name: '',
                        email: '',
                        phone: '',
                        whatsapp: '',
                        website: '',
                        youtube_channel: '',
                        instagram_id: '',
                        facebook_page: '',
                        bio: '',
                        country: 'India',
                        genres: [],
                        languages: [],
                      });
                    }}>
                      Cancel
                    </Button>
                  )}
                </div>
              </form>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader>
              <CardTitle>Your Labels</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="overflow-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-2">Name</th>
                      <th className="text-left py-2">Email</th>
                      <th className="text-left py-2">Country</th>
                      <th className="text-right py-2">Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {labels.length === 0 ? (
                      <tr>
                        <td colSpan={4} className="py-4 text-center text-gray-500">
                          No labels found. Add your first label above.
                        </td>
                      </tr>
                    ) : (
                      labels.map((label) => (
                        <tr key={label.id} className="border-b">
                          <td className="py-3">
                            <div className="flex items-center">
                              <Avatar className="h-8 w-8 mr-2">
                                <AvatarFallback>{label.name.charAt(0)}</AvatarFallback>
                              </Avatar>
                              {label.name}
                            </div>
                          </td>
                          <td className="py-3">{label.email || 'N/A'}</td>
                          <td className="py-3">{label.country}</td>
                          <td className="py-3 text-right space-x-2">
                            <Button variant="ghost" size="sm" onClick={() => editLabel(label)}>
                              <Edit className="h-4 w-4" />
                            </Button>
                            <Button variant="ghost" size="sm" onClick={() => deleteLabel(label.id)}>
                              <Trash className="h-4 w-4" />
                            </Button>
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ArtistManagement;
