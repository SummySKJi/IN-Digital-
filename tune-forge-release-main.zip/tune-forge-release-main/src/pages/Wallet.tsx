
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { WithdrawalRequest } from "@/types/database";

const Wallet = () => {
  const [balance, setBalance] = useState(0);
  const [withdrawalRequests, setWithdrawalRequests] = useState<WithdrawalRequest[]>([]);

  useEffect(() => {
    fetchWithdrawalRequests();
    // In a real app, this would fetch the actual balance from an API
    setBalance(512.75);
  }, []);

  const fetchWithdrawalRequests = async () => {
    try {
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.user?.id) return;
      
      const { data, error } = await supabase
        .from('withdrawal_requests')
        .select('*')
        .eq('user_id', session.session.user.id);
      
      if (error) throw error;
      
      if (data) {
        const typedRequests = data.map(item => ({
          id: item.id,
          user_id: item.user_id,
          amount: item.amount,
          payment_method: item.payment_method,
          account_details: item.account_details as Record<string, any>,
          status: item.status as 'pending' | 'approved' | 'rejected',
          created_at: item.created_at,
          updated_at: item.updated_at
        }));
        setWithdrawalRequests(typedRequests);
      }
    } catch (error) {
      console.error('Error fetching withdrawal requests:', error);
      toast.error('Failed to load your withdrawal history');
    }
  };

  const handleWithdraw = () => {
    // In a real app, this would open a withdrawal form
    toast.info("Withdrawal feature will be available soon");
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Wallet</h1>
      <p className="text-gray-500">Manage your earnings and withdrawals</p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Balance</CardTitle>
            <CardDescription>Your current earnings</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-baseline">
              <span className="text-3xl font-bold text-music-600">${balance.toFixed(2)}</span>
              <span className="text-gray-500 ml-2">USD</span>
            </div>
            <Button 
              className="w-full mt-4 bg-music-600 hover:bg-music-700"
              onClick={handleWithdraw}
              disabled={balance <= 0}
            >
              Withdraw Funds
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-lg">Statistics</CardTitle>
            <CardDescription>Your earnings overview</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-500">This month:</span>
                <span className="font-medium">$78.24</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Last month:</span>
                <span className="font-medium">$124.50</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">All time:</span>
                <span className="font-medium">$512.75</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <h2 className="text-xl font-bold mt-6">Withdrawal History</h2>
      {withdrawalRequests.length === 0 ? (
        <Card>
          <CardContent className="text-center py-6">
            <p className="text-gray-500">No withdrawal requests found.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {withdrawalRequests.map((request) => (
            <Card key={request.id}>
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row justify-between gap-4">
                  <div>
                    <h3 className="font-medium">${request.amount.toFixed(2)} USD</h3>
                    <p className="text-sm text-gray-600">
                      Method: {request.payment_method}
                    </p>
                    <p className="text-xs text-gray-400">
                      Requested on: {new Date(request.created_at || '').toLocaleDateString()}
                    </p>
                  </div>
                  <div>
                    <Badge className={getStatusBadgeClass(request.status)}>
                      {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                    </Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default Wallet;
