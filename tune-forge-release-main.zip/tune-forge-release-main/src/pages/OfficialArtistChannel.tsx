
import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { OfficialArtistChannelRequest } from "@/types/database";

const OfficialArtistChannel = () => {
  const [loading, setLoading] = useState(false);
  const [requests, setRequests] = useState<OfficialArtistChannelRequest[]>([]);
  const [youtubeChannelLink, setYoutubeChannelLink] = useState('');
  const [topicChannelLink, setTopicChannelLink] = useState('');
  const [artistId, setArtistId] = useState('');
  const [availableArtists, setAvailableArtists] = useState<{id: string, name: string}[]>([]);

  useEffect(() => {
    fetchRequests();
    fetchUserArtists();
  }, []);

  const fetchUserArtists = async () => {
    try {
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.user?.id) return;
      
      const { data, error } = await supabase
        .from('artists')
        .select('id, name')
        .eq('user_id', session.session.user.id);
      
      if (error) throw error;
      if (data) setAvailableArtists(data);
    } catch (error) {
      console.error('Error fetching artists:', error);
      toast.error('Failed to load your artists');
    }
  };

  const fetchRequests = async () => {
    try {
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.user?.id) return;
      
      const { data, error } = await supabase
        .from('official_artist_channel_requests')
        .select(`
          *,
          artists:artist_id(name)
        `)
        .eq('user_id', session.session.user.id);
      
      if (error) throw error;
      
      if (data) {
        const typedRequests = data.map(item => ({
          id: item.id,
          user_id: item.user_id,
          artist_id: item.artist_id,
          youtube_channel_link: item.youtube_channel_link,
          topic_channel_link: item.topic_channel_link || undefined,
          status: item.status as 'pending' | 'approved' | 'rejected',
          admin_notes: item.admin_notes || undefined,
          created_at: item.created_at,
          updated_at: item.updated_at,
          artist_name: item.artists?.name // Add artist name from the joined data
        }));
        setRequests(typedRequests);
      }
    } catch (error) {
      console.error('Error fetching requests:', error);
      toast.error('Failed to load your requests');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!youtubeChannelLink || !artistId) {
      toast.error('Please fill all required fields');
      return;
    }

    try {
      setLoading(true);
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.user?.id) {
        toast.error('You must be logged in to submit a request');
        return;
      }

      const { error } = await supabase
        .from('official_artist_channel_requests')
        .insert({
          user_id: session.session.user.id,
          artist_id: artistId,
          youtube_channel_link: youtubeChannelLink,
          topic_channel_link: topicChannelLink || null
        });

      if (error) throw error;
      
      toast.success('Request submitted successfully');
      setYoutubeChannelLink('');
      setTopicChannelLink('');
      setArtistId('');
      fetchRequests();
    } catch (error) {
      console.error('Error submitting request:', error);
      toast.error('Failed to submit request');
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadgeClass = (status: string) => {
    switch (status) {
      case 'approved':
        return 'bg-green-100 text-green-800';
      case 'rejected':
        return 'bg-red-100 text-red-800';
      default:
        return 'bg-yellow-100 text-yellow-800';
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Official Artist Channel</h1>
      <p className="text-gray-500">
        Request verification of your artist channel on YouTube
      </p>

      <Card>
        <CardHeader>
          <CardTitle>Submit New Request</CardTitle>
          <CardDescription>
            Provide your YouTube channel details to request official artist channel verification
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-4" onSubmit={handleSubmit}>
            <div className="space-y-2">
              <label htmlFor="artist" className="text-sm font-medium">
                Select Artist <span className="text-red-500">*</span>
              </label>
              <select
                id="artist"
                className="w-full p-2 border rounded-md"
                value={artistId}
                onChange={(e) => setArtistId(e.target.value)}
                required
              >
                <option value="">Select an artist...</option>
                {availableArtists.map((artist) => (
                  <option key={artist.id} value={artist.id}>
                    {artist.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label htmlFor="youtubeChannel" className="text-sm font-medium">
                YouTube Channel Link <span className="text-red-500">*</span>
              </label>
              <Input
                id="youtubeChannel"
                placeholder="https://youtube.com/c/YourChannel"
                value={youtubeChannelLink}
                onChange={(e) => setYoutubeChannelLink(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <label htmlFor="topicChannel" className="text-sm font-medium">
                Topic Channel Link (if available)
              </label>
              <Input
                id="topicChannel"
                placeholder="https://youtube.com/c/YourTopicChannel"
                value={topicChannelLink}
                onChange={(e) => setTopicChannelLink(e.target.value)}
              />
            </div>

            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? "Submitting..." : "Submit Request"}
            </Button>
          </form>
        </CardContent>
      </Card>

      <h2 className="text-xl font-bold mt-6">Your Requests</h2>
      {requests.length === 0 ? (
        <Card>
          <CardContent className="text-center py-6">
            <p className="text-gray-500">You haven't submitted any requests yet.</p>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {requests.map((request) => (
            <Card key={request.id}>
              <CardContent className="pt-6">
                <div className="flex flex-col md:flex-row justify-between gap-4">
                  <div className="space-y-2">
                    <h3 className="font-medium">
                      Artist: {request.artist_name || 'Unknown Artist'}
                    </h3>
                    <p className="text-sm text-gray-600 break-all">
                      Channel: {request.youtube_channel_link}
                    </p>
                    {request.topic_channel_link && (
                      <p className="text-sm text-gray-600 break-all">
                        Topic Channel: {request.topic_channel_link}
                      </p>
                    )}
                    <p className="text-xs text-gray-400">
                      Submitted on: {new Date(request.created_at || '').toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex flex-col items-end">
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${getStatusBadgeClass(
                        request.status
                      )}`}
                    >
                      {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                    </span>
                    {request.admin_notes && (
                      <div className="mt-2 text-sm">
                        <p className="font-medium">Admin notes:</p>
                        <p className="text-gray-600">{request.admin_notes}</p>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default OfficialArtistChannel;
