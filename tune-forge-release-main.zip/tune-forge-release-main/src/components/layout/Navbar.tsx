
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { Button } from "@/components/ui/button";
import { ChevronDown, Menu, X } from "lucide-react";

const Navbar = () => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <header className="bg-white/90 backdrop-blur-md border-b border-gray-100 sticky top-0 z-40">
      <nav className="container mx-auto px-4 py-3 flex items-center justify-between">
        {/* Logo */}
        <Link to="/" className="flex items-center space-x-2">
          <div className="text-2xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-music-600 to-music-800">
            TuneForge
          </div>
        </Link>

        {/* Desktop Navigation */}
        <div className="hidden md:flex items-center space-x-8">
          <Link to="/" className="text-sm font-medium text-gray-700 hover:text-music-600 transition-colors">Home</Link>
          <Link to="/features" className="text-sm font-medium text-gray-700 hover:text-music-600 transition-colors">Features</Link>
          <Link to="/pricing" className="text-sm font-medium text-gray-700 hover:text-music-600 transition-colors">Pricing</Link>
          <div className="relative group">
            <button className="flex items-center text-sm font-medium text-gray-700 hover:text-music-600 transition-colors">
              Resources
              <ChevronDown className="ml-1 h-4 w-4" />
            </button>
            <div className="absolute left-0 mt-2 w-48 bg-white rounded-md shadow-lg p-2 hidden group-hover:block">
              <Link to="/blog" className="block px-4 py-2 text-sm text-gray-700 hover:bg-music-50 rounded-md">Blog</Link>
              <Link to="/help" className="block px-4 py-2 text-sm text-gray-700 hover:bg-music-50 rounded-md">Help Center</Link>
              <Link to="/faq" className="block px-4 py-2 text-sm text-gray-700 hover:bg-music-50 rounded-md">FAQ</Link>
            </div>
          </div>
        </div>

        {/* Authentication Buttons */}
        <div className="hidden md:flex items-center space-x-4">
          <Link to="/login">
            <Button variant="outline" className="border-music-600 text-music-600 hover:bg-music-50">
              Log In
            </Button>
          </Link>
          <Link to="/register">
            <Button className="bg-music-600 hover:bg-music-700">
              Sign Up Free
            </Button>
          </Link>
          <Link to="/admin-login">
            <Button variant="ghost" className="text-sm text-gray-500 hover:text-music-600">
              Admin
            </Button>
          </Link>
        </div>

        {/* Mobile menu button */}
        <div className="md:hidden">
          <button 
            onClick={toggleMobileMenu}
            className="text-gray-700 hover:text-music-600 focus:outline-none"
          >
            {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      {/* Mobile Navigation */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 py-4 px-4 animate-fade-in">
          <div className="flex flex-col space-y-4">
            <Link to="/" className="text-base font-medium text-gray-700 hover:text-music-600 transition-colors">Home</Link>
            <Link to="/features" className="text-base font-medium text-gray-700 hover:text-music-600 transition-colors">Features</Link>
            <Link to="/pricing" className="text-base font-medium text-gray-700 hover:text-music-600 transition-colors">Pricing</Link>
            <div className="relative">
              <button className="flex items-center text-base font-medium text-gray-700 hover:text-music-600 transition-colors">
                Resources
                <ChevronDown className="ml-1 h-4 w-4" />
              </button>
              <div className="mt-2 ml-4 space-y-2">
                <Link to="/blog" className="block text-sm text-gray-700 hover:text-music-600">Blog</Link>
                <Link to="/help" className="block text-sm text-gray-700 hover:text-music-600">Help Center</Link>
                <Link to="/faq" className="block text-sm text-gray-700 hover:text-music-600">FAQ</Link>
              </div>
            </div>
            <div className="pt-4 flex flex-col space-y-3">
              <Link to="/login">
                <Button variant="outline" className="w-full border-music-600 text-music-600">
                  Log In
                </Button>
              </Link>
              <Link to="/register">
                <Button className="w-full bg-music-600 hover:bg-music-700">
                  Sign Up Free
                </Button>
              </Link>
              <Link to="/admin-login">
                <Button variant="ghost" className="w-full text-sm text-gray-500 hover:text-music-600">
                  Admin
                </Button>
              </Link>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};

export default Navbar;
