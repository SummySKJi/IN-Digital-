
import React, { useState } from 'react';
import { Outlet } from 'react-router-dom';
import { useIsMobile } from '@/hooks/use-mobile';
import Header from '@/components/dashboard/Header';
import Sidebar from '@/components/dashboard/Sidebar';
import MobileSidebar from '@/components/dashboard/MobileSidebar';

const DashboardLayout = () => {
  const isMobile = useIsMobile();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Header 
        isMobile={isMobile} 
        toggleMobileMenu={toggleMobileMenu} 
      />
      
      <div className="flex">
        {!isMobile && (
          <Sidebar 
            isMobile={isMobile} 
            mobileMenuOpen={mobileMenuOpen} 
            toggleMobileMenu={toggleMobileMenu} 
          />
        )}
        
        {isMobile && (
          <MobileSidebar 
            isOpen={mobileMenuOpen} 
            onClose={toggleMobileMenu} 
          />
        )}
        
        {/* Main Content */}
        <main className="md:ml-64 flex-1 p-4 sm:p-6 overflow-auto">
          <Outlet />
        </main>
      </div>
    </div>
  );
};

export default DashboardLayout;
