
import React from 'react';

const Platforms = () => {
  const platforms = [
    { name: 'Spotify', logo: 'spotify.svg' },
    { name: 'Apple Music', logo: 'apple-music.svg' },
    { name: 'YouTube Music', logo: 'youtube-music.svg' },
    { name: 'Amazon Music', logo: 'amazon-music.svg' },
    { name: 'TikTok', logo: 'tiktok.svg' },
    { name: 'Deezer', logo: 'deezer.svg' },
    { name: 'Instagram', logo: 'instagram.svg' },
    { name: 'Pandora', logo: 'pandora.svg' }
  ];

  return (
    <section className="py-12 bg-white">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-2xl font-semibold mb-2">Reach Listeners Everywhere</h2>
          <p className="text-gray-600">Your music on all major streaming platforms worldwide</p>
        </div>
        
        <div className="flex flex-wrap items-center justify-center gap-8 md:gap-12">
          {/* Since we don't have logos uploaded, we'll use text placeholders */}
          {platforms.map((platform) => (
            <div 
              key={platform.name}
              className="flex items-center justify-center w-24 h-16 grayscale hover:grayscale-0 transition-all duration-200"
            >
              <div className="text-lg font-medium text-gray-800">{platform.name}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Platforms;
