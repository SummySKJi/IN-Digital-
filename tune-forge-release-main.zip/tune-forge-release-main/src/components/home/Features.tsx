
import React from 'react';
import { Globe, BarChart3, DollarSign, Clock, ShieldCheck, HelpCircle } from 'lucide-react';

const FeatureCard = ({ 
  icon: Icon, 
  title, 
  description 
}: { 
  icon: React.ElementType; 
  title: string; 
  description: string;
}) => (
  <div className="bg-white rounded-xl p-6 shadow-sm border border-gray-100 hover:shadow-md transition-shadow">
    <div className="h-12 w-12 rounded-lg bg-music-100 flex items-center justify-center mb-5">
      <Icon className="h-6 w-6 text-music-600" />
    </div>
    <h3 className="text-lg font-semibold mb-2">{title}</h3>
    <p className="text-gray-600">{description}</p>
  </div>
);

const Features = () => {
  const features = [
    {
      icon: Globe,
      title: 'Worldwide Distribution',
      description: 'Distribute your music to over 150 streaming platforms including Spotify, Apple Music, TikTok and more.'
    },
    {
      icon: BarChart3,
      title: 'Advanced Analytics',
      description: 'Track your streams, revenue, and audience demographics with our detailed analytics dashboard.'
    },
    {
      icon: DollarSign,
      title: 'Keep 100% of Royalties',
      description: 'No hidden fees. Keep all your streaming royalties and get paid monthly for your music.'
    },
    {
      icon: Clock,
      title: 'Fast Release Times',
      description: 'Get your music on all major platforms within days, not weeks or months.'
    },
    {
      icon: ShieldCheck,
      title: 'Copyright Protection',
      description: 'Your music is protected with Content ID to prevent unauthorized use and maximize revenue.'
    },
    {
      icon: HelpCircle,
      title: '24/7 Artist Support',
      description: 'Get help whenever you need it with our dedicated support team available around the clock.'
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl font-bold mb-4">Everything You Need to Succeed</h2>
          <p className="text-xl text-gray-600">
            Our all-in-one platform gives independent artists the tools and services to grow their career.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <FeatureCard 
              key={index}
              icon={feature.icon}
              title={feature.title}
              description={feature.description}
            />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
