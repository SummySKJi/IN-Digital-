
import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { ArrowRight, Music } from 'lucide-react';

const CallToAction = () => {
  return (
    <section className="py-20 bg-music-900">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center justify-center p-3 bg-music-800/50 rounded-full mb-6">
            <Music className="h-6 w-6 text-music-300" />
          </div>
          
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-6">
            Ready to Share Your Music with the World?
          </h2>
          
          <p className="text-xl text-music-200 mb-10">
            Join thousands of independent artists who trust TuneForge to distribute their music globally, 
            track their success, and get paid what they deserve.
          </p>
          
          <div className="flex flex-col sm:flex-row items-center justify-center space-y-4 sm:space-y-0 sm:space-x-6">
            <Link to="/register">
              <Button className="w-full sm:w-auto bg-music-500 hover:bg-music-600 text-white px-8 py-6 rounded-md text-base">
                Start Distributing Now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
            <Link to="/contact">
              <Button variant="outline" className="w-full sm:w-auto border-music-400 text-music-200 hover:bg-music-800 hover:text-white px-8 py-6 rounded-md text-base">
                Talk to Sales
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default CallToAction;
