
import React from 'react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { ArrowRight, CheckCircle } from 'lucide-react';

const Hero = () => {
  return (
    <div className="relative overflow-hidden">
      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-b from-music-900/10 to-transparent pointer-events-none" />

      <div className="container mx-auto px-4 py-20 md:py-28">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          <div className="flex flex-col space-y-6 max-w-xl">
            <div className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium bg-music-100 text-music-800 mb-2">
              <span className="flex h-2 w-2 rounded-full bg-music-500 mr-2"></span>
              Music Distribution Made Simple
            </div>
            
            <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight leading-tight">
              Distribute Your Music <span className="text-gradient">Worldwide</span>
            </h1>
            
            <p className="text-lg md:text-xl text-gray-600 leading-relaxed">
              Reach millions of listeners on Spotify, Apple Music, TikTok, and 150+ streaming platforms. Keep 100% of your royalties.
            </p>
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-4">
              <ul className="space-y-3">
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-sm text-gray-700">Unlimited Releases</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-sm text-gray-700">Keep 100% Rights</span>
                </li>
              </ul>
              <ul className="space-y-3">
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-sm text-gray-700">Detailed Analytics</span>
                </li>
                <li className="flex items-center">
                  <CheckCircle className="h-5 w-5 text-green-500 mr-2" />
                  <span className="text-sm text-gray-700">Fast Payouts</span>
                </li>
              </ul>
            </div>
            
            <div className="flex flex-col sm:flex-row space-y-3 sm:space-y-0 sm:space-x-4 pt-4">
              <Link to="/register">
                <Button className="w-full sm:w-auto bg-music-600 hover:bg-music-700 text-white px-8 py-6 rounded-md text-base">
                  Get Started Free
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
              <Link to="/pricing">
                <Button variant="outline" className="w-full sm:w-auto border-music-600 text-music-600 hover:bg-music-50 px-8 py-6 rounded-md text-base">
                  View Pricing
                </Button>
              </Link>
            </div>
          </div>
          
          <div className="relative hidden md:block">
            <div className="absolute -top-6 -right-6 w-64 h-64 bg-music-400/20 rounded-full filter blur-3xl animate-pulse-subtle"></div>
            <div className="absolute -bottom-10 -left-10 w-72 h-72 bg-blue-400/20 rounded-full filter blur-3xl animate-pulse-subtle"></div>
            
            <div className="relative bg-white shadow-xl rounded-2xl p-4 border border-gray-100">
              <div className="aspect-[4/3] rounded-lg overflow-hidden bg-gray-100">
                <img 
                  src="https://images.unsplash.com/photo-1470225620780-dba8ba36b745?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1770&q=80" 
                  alt="Artist performing"
                  className="w-full h-full object-cover"
                />
              </div>
              
              <div className="mt-4 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h3 className="text-lg font-semibold">Monthly Streams</h3>
                    <p className="text-gray-500 text-sm">Last 30 days</p>
                  </div>
                  <div className="text-2xl font-bold text-music-700">243,619</div>
                </div>
                
                <div className="h-2 bg-gray-100 rounded-full overflow-hidden">
                  <div className="h-full bg-gradient-to-r from-music-500 to-blue-400 w-[65%]"></div>
                </div>
                
                <div className="grid grid-cols-3 gap-2 pt-2">
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-500">Spotify</p>
                    <p className="text-sm font-medium">124,853</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-500">Apple</p>
                    <p className="text-sm font-medium">68,291</p>
                  </div>
                  <div className="bg-gray-50 rounded-lg p-3">
                    <p className="text-xs text-gray-500">Others</p>
                    <p className="text-sm font-medium">50,475</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Hero;
