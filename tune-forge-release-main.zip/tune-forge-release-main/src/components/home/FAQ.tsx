
import React from 'react';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const FAQ = () => {
  const faqs = [
    {
      question: "How long does it take for my music to go live?",
      answer: "Most releases are available on major platforms within 2-5 business days after approval. For scheduled releases, you can set a future release date up to 6 months in advance."
    },
    {
      question: "What audio formats do you accept?",
      answer: "We accept WAV and FLAC files for the best quality. Your music will be automatically converted to the appropriate format for each streaming platform."
    },
    {
      question: "How do I get paid and how often?",
      answer: "You'll receive monthly payments for all your streaming royalties. Payments are made via PayPal, direct deposit, or other payment methods with a minimum threshold of $10."
    },
    {
      question: "Can I distribute cover songs?",
      answer: "Yes! You can distribute cover songs, but you'll need to obtain the proper mechanical licenses. We can help you secure these licenses for an additional fee."
    },
    {
      question: "What happens if I want to remove my music?",
      answer: "You can request to take down your music at any time. Most platforms will remove your content within 1-2 weeks of the request."
    },
    {
      question: "Do you offer promotional services?",
      answer: "Our Professional and Label plans include promotional tools like pre-save campaigns and social media integration. We also offer additional promotional services for an extra fee."
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl font-bold mb-4">Frequently Asked Questions</h2>
          <p className="text-xl text-gray-600">
            Everything you need to know about TuneForge music distribution.
          </p>
        </div>
        
        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem value={`item-${index}`} key={index}>
                <AccordionTrigger className="text-left font-medium">{faq.question}</AccordionTrigger>
                <AccordionContent className="text-gray-600">{faq.answer}</AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
        
        <div className="text-center mt-12">
          <p className="text-gray-600 mb-4">Still have questions?</p>
          <a href="/contact" className="text-music-600 font-medium hover:text-music-700 underline">
            Contact our support team
          </a>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
