
import React from 'react';
import { Button } from '@/components/ui/button';
import { Check } from 'lucide-react';

const PricingCard = ({ 
  title, 
  price, 
  description, 
  features,
  isPopular = false 
}: { 
  title: string; 
  price: string;
  description: string;
  features: string[];
  isPopular?: boolean;
}) => (
  <div className={`rounded-2xl overflow-hidden ${isPopular ? 'border-2 border-music-500 relative' : 'border border-gray-200'}`}>
    {isPopular && (
      <div className="bg-music-500 text-white text-xs font-bold uppercase tracking-wider py-1 text-center">
        Most Popular
      </div>
    )}
    <div className="p-6 md:p-8 bg-white">
      <h3 className="text-xl font-semibold mb-2">{title}</h3>
      <div className="flex items-baseline mb-4">
        <span className="text-3xl md:text-4xl font-bold">{price}</span>
        {price !== 'Custom' && <span className="text-gray-500 ml-2">/year</span>}
      </div>
      <p className="text-gray-600 mb-6">{description}</p>
      
      <Button 
        className={`w-full ${isPopular ? 'bg-music-600 hover:bg-music-700' : 'bg-gray-900 hover:bg-gray-800'}`}
      >
        Get Started
      </Button>
      
      <ul className="mt-8 space-y-4">
        {features.map((feature, index) => (
          <li key={index} className="flex items-start">
            <Check className="h-5 w-5 text-green-500 mt-0.5 mr-3 flex-shrink-0" />
            <span className="text-gray-600">{feature}</span>
          </li>
        ))}
      </ul>
    </div>
  </div>
);

const Pricing = () => {
  const pricingPlans = [
    {
      title: 'Starter',
      price: '$19',
      description: 'Perfect for new artists just getting started.',
      features: [
        'Single/EP Distribution (up to 2 releases/year)',
        'Basic Analytics Dashboard',
        'Distribution to Major Platforms',
        'Monthly Payments',
        'Email Support'
      ]
    },
    {
      title: 'Professional',
      price: '$49',
      description: 'Everything you need to grow as an artist.',
      features: [
        'Unlimited Distribution',
        'Advanced Analytics Dashboard',
        'Distribution to All Platforms (150+)',
        'Weekly Payments',
        'Priority Support',
        'Content ID for YouTube',
        'Cover Art Creator'
      ],
      isPopular: true
    },
    {
      title: 'Label',
      price: 'Custom',
      description: 'For labels and artist management teams.',
      features: [
        'Multiple Artist Accounts',
        'Bulk Distribution',
        'Label Analytics Dashboard',
        'Custom Payout Splits',
        '24/7 Dedicated Support',
        'API Access',
        'Custom Branding Options'
      ]
    }
  ];

  return (
    <section className="py-16 bg-gray-50">
      <div className="container mx-auto px-4">
        <div className="text-center max-w-3xl mx-auto mb-12">
          <h2 className="text-3xl font-bold mb-4">Simple, Transparent Pricing</h2>
          <p className="text-xl text-gray-600">
            Choose the plan that's right for your music career.
          </p>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {pricingPlans.map((plan, index) => (
            <PricingCard 
              key={index}
              title={plan.title}
              price={plan.price}
              description={plan.description}
              features={plan.features}
              isPopular={plan.isPopular}
            />
          ))}
        </div>
        
        <div className="mt-12 text-center text-gray-600">
          All plans include streaming to major platforms, earnings tracking, and no hidden fees.
        </div>
      </div>
    </section>
  );
};

export default Pricing;
