
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toast } from "sonner";
import { Upload, CheckCircle2, X } from 'lucide-react';

interface UploadCoverArtProps {
  coverImage: File | null;
  coverImageUrl: string | null;
  setCoverImage: (file: File | null) => void;
  setCoverImageUrl: (url: string | null) => void;
}

const UploadCoverArt: React.FC<UploadCoverArtProps> = ({ 
  coverImage, 
  coverImageUrl, 
  setCoverImage, 
  setCoverImageUrl 
}) => {
  const handleCoverImageUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files[0]) {
      setCoverImage(files[0]);
      const objectUrl = URL.createObjectURL(files[0]);
      setCoverImageUrl(objectUrl);
      toast.success("Cover art uploaded successfully");
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <CheckCircle2 className="mr-2 h-5 w-5 text-music-600" />
          Upload Cover Art
        </CardTitle>
        <CardDescription>
          Upload high-quality artwork (3000x3000px recommended)
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col sm:flex-row gap-6">
          <div className={`border-2 border-dashed rounded-lg h-60 w-full sm:w-60 flex-shrink-0 ${
            coverImage ? 'border-green-500' : 'border-gray-300 hover:border-music-500'
          } transition-colors flex flex-col items-center justify-center cursor-pointer relative overflow-hidden`}>
            {coverImageUrl ? (
              <img 
                src={coverImageUrl} 
                alt="Cover Preview" 
                className="absolute inset-0 h-full w-full object-cover"
              />
            ) : (
              <>
                <Upload className="h-12 w-12 text-gray-400 mb-4" />
                <p className="text-sm text-gray-500 mb-1 text-center">Drag cover art</p>
                <p className="text-sm text-gray-500 mb-1 text-center">or click to browse</p>
              </>
            )}
            <input 
              type="file" 
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
              onChange={handleCoverImageUpload}
              accept=".jpg,.jpeg,.png"
            />
          </div>
          
          <div className="space-y-3">
            <h3 className="font-medium">Cover Art Requirements:</h3>
            <ul className="text-sm text-gray-600 space-y-1">
              <li className="flex items-start">
                <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 mr-2" />
                Square image (minimum 3000x3000 pixels)
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 mr-2" />
                JPG or PNG format
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 mr-2" />
                No explicit content or third-party logos
              </li>
              <li className="flex items-start">
                <CheckCircle2 className="h-4 w-4 text-green-500 mt-0.5 mr-2" />
                No text (including title, artist name, or website)
              </li>
            </ul>
            
            {coverImage && (
              <Button 
                variant="outline" 
                size="sm"
                onClick={() => {
                  setCoverImage(null);
                  setCoverImageUrl(null);
                }}
                className="flex items-center"
              >
                <X className="h-4 w-4 mr-1" />
                Remove Cover Art
              </Button>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default UploadCoverArt;
