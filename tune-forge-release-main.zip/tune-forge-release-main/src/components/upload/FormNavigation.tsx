
import React from 'react';
import { Button } from '@/components/ui/button';
import { ChevronLeft, ChevronRight } from 'lucide-react';

interface FormNavigationProps {
  currentStep: number;
  onNext: () => void;
  onPrev: () => void;
  canProgress: boolean;
  isSubmitting?: boolean;
  showSubmitButton?: boolean;
  onSubmit?: () => void;
}

const FormNavigation: React.FC<FormNavigationProps> = ({
  currentStep,
  onNext,
  onPrev,
  canProgress,
  isSubmitting,
  showSubmitButton,
  onSubmit
}) => {
  return (
    <div className="flex justify-between">
      {currentStep > 1 && (
        <Button variant="outline" onClick={onPrev}>
          <ChevronLeft className="mr-1 h-4 w-4" />
          Back
        </Button>
      )}
      
      {!showSubmitButton && (
        <Button
          onClick={onNext}
          disabled={!canProgress}
          className="bg-music-600 hover:bg-music-700 ml-auto"
        >
          Next: {currentStep === 1 ? 'Release Info' : 'Distribution'}
          <ChevronRight className="ml-1 h-4 w-4" />
        </Button>
      )}
      
      {showSubmitButton && (
        <Button
          onClick={onSubmit}
          className="bg-music-600 hover:bg-music-700 ml-auto"
          disabled={isSubmitting}
        >
          {isSubmitting ? "Submitting..." : "Submit for Distribution"}
        </Button>
      )}
    </div>
  );
};

export default FormNavigation;

