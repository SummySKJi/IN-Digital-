
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Checkbox } from "@/components/ui/checkbox";
import { Globe } from 'lucide-react';

interface PlatformSelectionProps {
  selectedPlatforms: string[];
  setSelectedPlatforms: React.Dispatch<React.SetStateAction<string[]>>;
}

const PlatformSelection: React.FC<PlatformSelectionProps> = ({ 
  selectedPlatforms, 
  setSelectedPlatforms 
}) => {
  const handlePlatformToggle = (platform: string) => {
    if (selectedPlatforms.includes(platform)) {
      setSelectedPlatforms(selectedPlatforms.filter(p => p !== platform));
    } else {
      setSelectedPlatforms([...selectedPlatforms, platform]);
    }
  };

  const handleSelectAll = (platforms: string[]) => {
    // If all platforms are already selected, deselect all
    const allSelected = platforms.every(p => selectedPlatforms.includes(p));
    
    if (allSelected) {
      setSelectedPlatforms(selectedPlatforms.filter(p => !platforms.includes(p)));
    } else {
      // Add any platforms that aren't already selected
      const newPlatforms = platforms.filter(p => !selectedPlatforms.includes(p));
      setSelectedPlatforms([...selectedPlatforms, ...newPlatforms]);
    }
  };

  const streamingPlatforms = [
    'Spotify', 'Apple Music', 'YouTube Music', 'Amazon Music', 'Deezer', 'Tidal', 
    'Pandora', 'iHeartRadio', 'JioSaavn', 'Wynk Music', 'Gaana', 'Hungama', 'Resso'
  ];
  
  const stores = [
    'iTunes', 'Amazon', 'Google Play', 'Bandcamp'
  ];
  
  const socialPlatforms = [
    'TikTok', 'Instagram', 'Facebook', 'Snapchat', 'YouTube Content ID'
  ];

  const allPlatforms = [...streamingPlatforms, ...stores, ...socialPlatforms];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Globe className="mr-2 h-5 w-5 text-music-600" />
          Choose Platforms
        </CardTitle>
        <CardDescription>
          Select where you want to distribute your music (250+ platforms available)
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex justify-between items-center mb-4">
          <span className="text-sm font-medium">
            Selected: {selectedPlatforms.length} platforms
          </span>
          <button 
            type="button" 
            onClick={() => handleSelectAll(allPlatforms)}
            className="text-sm text-music-600 hover:text-music-800 font-medium"
          >
            {allPlatforms.every(p => selectedPlatforms.includes(p)) ? "Deselect All" : "Select All"}
          </button>
        </div>
        
        <Tabs defaultValue="all">
          <TabsList className="mb-4">
            <TabsTrigger value="all">All Platforms</TabsTrigger>
            <TabsTrigger value="streaming">Streaming</TabsTrigger>
            <TabsTrigger value="stores">Stores</TabsTrigger>
            <TabsTrigger value="social">Social Media</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            <div className="mb-2 flex justify-end">
              <button 
                type="button" 
                onClick={() => handleSelectAll(allPlatforms)}
                className="text-xs text-music-600 hover:text-music-800 font-medium"
              >
                {allPlatforms.every(p => selectedPlatforms.includes(p)) ? "Deselect All" : "Select All"}
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
              {allPlatforms.map((platform) => (
                <div 
                  key={platform} 
                  className={`flex items-center space-x-2 p-2 border rounded-lg cursor-pointer hover:bg-gray-50 ${
                    selectedPlatforms.includes(platform) ? 'border-music-500 bg-music-50' : 'border-gray-200'
                  }`}
                  onClick={() => handlePlatformToggle(platform)}
                >
                  <Checkbox 
                    id={platform} 
                    checked={selectedPlatforms.includes(platform)}
                    onCheckedChange={() => {}}
                    className="pointer-events-none"
                  />
                  <label
                    htmlFor={platform}
                    className="text-sm font-medium leading-none cursor-pointer w-full"
                  >
                    {platform}
                  </label>
                </div>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="streaming">
            <div className="mb-2 flex justify-end">
              <button 
                type="button" 
                onClick={() => handleSelectAll(streamingPlatforms)}
                className="text-xs text-music-600 hover:text-music-800 font-medium"
              >
                {streamingPlatforms.every(p => selectedPlatforms.includes(p)) ? "Deselect All" : "Select All"}
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
              {streamingPlatforms.map((platform) => (
                <div 
                  key={platform} 
                  className={`flex items-center space-x-2 p-2 border rounded-lg cursor-pointer hover:bg-gray-50 ${
                    selectedPlatforms.includes(platform) ? 'border-music-500 bg-music-50' : 'border-gray-200'
                  }`}
                  onClick={() => handlePlatformToggle(platform)}
                >
                  <Checkbox 
                    id={`${platform}-streaming`} 
                    checked={selectedPlatforms.includes(platform)}
                    onCheckedChange={() => {}}
                    className="pointer-events-none"
                  />
                  <label
                    htmlFor={`${platform}-streaming`}
                    className="text-sm font-medium leading-none cursor-pointer w-full"
                  >
                    {platform}
                  </label>
                </div>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="stores">
            <div className="mb-2 flex justify-end">
              <button 
                type="button" 
                onClick={() => handleSelectAll(stores)}
                className="text-xs text-music-600 hover:text-music-800 font-medium"
              >
                {stores.every(p => selectedPlatforms.includes(p)) ? "Deselect All" : "Select All"}
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
              {stores.map((platform) => (
                <div 
                  key={platform} 
                  className={`flex items-center space-x-2 p-2 border rounded-lg cursor-pointer hover:bg-gray-50 ${
                    selectedPlatforms.includes(platform) ? 'border-music-500 bg-music-50' : 'border-gray-200'
                  }`}
                  onClick={() => handlePlatformToggle(platform)}
                >
                  <Checkbox 
                    id={`${platform}-stores`} 
                    checked={selectedPlatforms.includes(platform)}
                    onCheckedChange={() => {}}
                    className="pointer-events-none"
                  />
                  <label
                    htmlFor={`${platform}-stores`}
                    className="text-sm font-medium leading-none cursor-pointer w-full"
                  >
                    {platform}
                  </label>
                </div>
              ))}
            </div>
          </TabsContent>
          
          <TabsContent value="social">
            <div className="mb-2 flex justify-end">
              <button 
                type="button" 
                onClick={() => handleSelectAll(socialPlatforms)}
                className="text-xs text-music-600 hover:text-music-800 font-medium"
              >
                {socialPlatforms.every(p => selectedPlatforms.includes(p)) ? "Deselect All" : "Select All"}
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-2">
              {socialPlatforms.map((platform) => (
                <div 
                  key={platform} 
                  className={`flex items-center space-x-2 p-2 border rounded-lg cursor-pointer hover:bg-gray-50 ${
                    selectedPlatforms.includes(platform) ? 'border-music-500 bg-music-50' : 'border-gray-200'
                  }`}
                  onClick={() => handlePlatformToggle(platform)}
                >
                  <Checkbox 
                    id={`${platform}-social`} 
                    checked={selectedPlatforms.includes(platform)}
                    onCheckedChange={() => {}}
                    className="pointer-events-none"
                  />
                  <label
                    htmlFor={`${platform}-social`}
                    className="text-sm font-medium leading-none cursor-pointer w-full"
                  >
                    {platform}
                  </label>
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};

export default PlatformSelection;
