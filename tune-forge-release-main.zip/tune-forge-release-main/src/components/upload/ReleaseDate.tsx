
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { format } from "date-fns";
import { CalendarIcon, Clock } from 'lucide-react';

interface ReleaseDateProps {
  releaseDate: Date | undefined;
  setReleaseDate: (date: Date | undefined) => void;
}

const ReleaseDate: React.FC<ReleaseDateProps> = ({ releaseDate, setReleaseDate }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Clock className="mr-2 h-5 w-5 text-music-600" />
          Release Date
        </CardTitle>
        <CardDescription>
          When do you want your music to go live?
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-4">
            <div className="flex items-center space-x-3">
              <div>
                <input 
                  type="radio" 
                  id="release-asap" 
                  name="release-timing" 
                  className="peer hidden" 
                  defaultChecked 
                />
                <label 
                  htmlFor="release-asap"
                  className="flex items-center space-x-2 p-3 border rounded-lg cursor-pointer 
                    peer-checked:border-music-500 peer-checked:bg-music-50"
                >
                  <div className="h-4 w-4 rounded-full border border-gray-300 flex items-center justify-center peer-checked:border-music-500">
                    <div className="h-2 w-2 rounded-full peer-checked:bg-music-500"></div>
                  </div>
                  <div>
                    <h3 className="font-medium">Release ASAP</h3>
                    <p className="text-xs text-gray-500">We'll distribute as soon as approved (2-5 days)</p>
                  </div>
                </label>
              </div>
            </div>
            
            <div className="flex items-center space-x-3">
              <div>
                <input 
                  type="radio" 
                  id="release-scheduled" 
                  name="release-timing" 
                  className="peer hidden" 
                />
                <label 
                  htmlFor="release-scheduled"
                  className="flex items-center space-x-2 p-3 border rounded-lg cursor-pointer 
                    peer-checked:border-music-500 peer-checked:bg-music-50"
                >
                  <div className="h-4 w-4 rounded-full border border-gray-300 flex items-center justify-center peer-checked:border-music-500">
                    <div className="h-2 w-2 rounded-full peer-checked:bg-music-500"></div>
                  </div>
                  <div>
                    <h3 className="font-medium">Schedule for later</h3>
                    <p className="text-xs text-gray-500">Choose a specific release date</p>
                  </div>
                </label>
              </div>
            </div>
            
            <div className="ml-6">
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant={"outline"}
                    className={"w-full justify-start text-left font-normal"}
                  >
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {releaseDate ? format(releaseDate, "PPP") : <span>Pick a date</span>}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={releaseDate}
                    onSelect={setReleaseDate}
                    initialFocus
                    disabled={(date) => {
                      // Disable dates less than 7 days in the future
                      const today = new Date();
                      const minDate = new Date();
                      minDate.setDate(today.getDate() + 7);
                      return date < minDate;
                    }}
                  />
                </PopoverContent>
              </Popover>
              <p className="text-xs text-gray-500 mt-1">
                Please allow at least 7 days for review and distribution
              </p>
            </div>
          </div>
          
          <div>
            <h3 className="font-medium mb-3">Pre-save Campaign</h3>
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-start mb-3">
                <Checkbox id="pre-save" className="mt-1" />
                <div className="ml-2">
                  <Label htmlFor="pre-save" className="font-medium">Enable Pre-save</Label>
                  <p className="text-xs text-gray-500">
                    Let fans save your release before it goes live. 
                    Perfect for building momentum for your release.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ReleaseDate;
