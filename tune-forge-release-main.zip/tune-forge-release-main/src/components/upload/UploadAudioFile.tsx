
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { toast } from "sonner";
import { Upload, Music, X } from 'lucide-react';

interface UploadAudioFileProps {
  uploadedFile: File | null;
  setUploadedFile: (file: File | null) => void;
  uploadProgress?: number;
}

const UploadAudioFile: React.FC<UploadAudioFileProps> = ({ 
  uploadedFile, 
  setUploadedFile,
  uploadProgress = 0
}) => {
  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files && files[0]) {
      // Check file type
      const fileType = files[0].type;
      if (!fileType.includes('audio/mpeg') && !fileType.includes('audio/wav')) {
        toast.error('Please upload an MP3 or WAV file');
        return;
      }
      
      // Check file size (max 50MB)
      if (files[0].size > 50 * 1024 * 1024) {
        toast.error('File size exceeds 50MB limit');
        return;
      }
      
      setUploadedFile(files[0]);
      toast.success(`File "${files[0].name}" uploaded successfully`);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Music className="mr-2 h-5 w-5 text-music-600" />
          Upload Audio File
        </CardTitle>
        <CardDescription>
          Upload your music in WAV or MP3 format (Max 50MB)
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className={`border-2 border-dashed rounded-lg p-6 ${
          uploadedFile ? 'border-green-500 bg-green-50' : 'border-gray-300 hover:border-music-500'
        } transition-colors flex flex-col items-center justify-center cursor-pointer relative`}>
          {!uploadedFile ? (
            <>
              <Upload className="h-12 w-12 text-gray-400 mb-4" />
              <h3 className="text-lg font-medium mb-1">Drop your audio file here</h3>
              <p className="text-sm text-gray-500 mb-3">or click to browse</p>
              <p className="text-xs text-gray-400">Supports WAV, MP3 (Max 50MB)</p>
            </>
          ) : (
            <>
              <Music className="h-12 w-12 text-green-500 mb-4" />
              <h3 className="text-lg font-medium mb-1">File uploaded successfully</h3>
              <p className="text-sm text-gray-600 mb-2">{uploadedFile.name}</p>
              <div className="flex items-center">
                <span className="text-xs bg-green-100 text-green-800 px-2 py-1 rounded-full mr-2">{uploadedFile.type}</span>
                <span className="text-xs text-gray-500">{(uploadedFile.size / (1024 * 1024)).toFixed(2)} MB</span>
              </div>
              
              {uploadProgress > 0 && (
                <div className="w-full mt-4">
                  <div className="flex justify-between text-xs text-gray-600 mb-1">
                    <span>Upload progress</span>
                    <span>{uploadProgress}%</span>
                  </div>
                  <Progress value={uploadProgress} className="h-2" />
                </div>
              )}
              
              {uploadProgress === 0 && (
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="mt-3"
                  onClick={(e) => {
                    e.stopPropagation();
                    setUploadedFile(null);
                  }}
                >
                  <X className="h-4 w-4 mr-1" />
                  Remove File
                </Button>
              )}
            </>
          )}
          <input 
            type="file" 
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" 
            onChange={handleFileUpload}
            accept=".wav,.mp3"
            disabled={uploadProgress > 0}
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default UploadAudioFile;
