
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Music } from 'lucide-react';
import { Artist, Label as LabelType } from '@/types/database';

interface ReleaseInfoType {
  title: string;
  primaryArtist: string;
  artistId: string;
  featuredArtists: string;
  composer: string;
  producer: string;
  album: string;
  releaseType: string;
  genre: string;
  language: string;
  explicit: boolean;
  copyright: string;
  label: string;
  labelId: string;
  upc: string;
  isrc: string;
  notes: string;
  instagramId: string;
  publisher: string;
}

interface BasicInformationProps {
  releaseInfo: ReleaseInfoType;
  handleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => void;
  handleSelectChange: (name: string, value: string) => void;
  handleExplicitChange: (checked: boolean) => void;
  handleArtistChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  handleLabelChange: (e: React.ChangeEvent<HTMLSelectElement>) => void;
  handleReleaseTypeChange: (type: string) => void;
  artists: Artist[];
  labels: LabelType[];
}

const BasicInformation: React.FC<BasicInformationProps> = ({ 
  releaseInfo,
  handleChange,
  handleSelectChange,
  handleExplicitChange,
  handleArtistChange,
  handleLabelChange,
  handleReleaseTypeChange,
  artists,
  labels
}) => {
  const indianLanguages = [
    { value: "hindi", label: "Hindi" },
    { value: "rajasthani", label: "Rajasthani" },
    { value: "haryanvi", label: "Haryanvi" },
    { value: "punjabi", label: "Punjabi" },
    { value: "bengali", label: "Bengali" },
    { value: "telugu", label: "Telugu" },
    { value: "tamil", label: "Tamil" },
    { value: "malayalam", label: "Malayalam" },
    { value: "kannada", label: "Kannada" },
    { value: "gujarati", label: "Gujarati" },
    { value: "marathi", label: "Marathi" },
    { value: "odia", label: "Odia" },
    { value: "assamese", label: "Assamese" },
    { value: "bhojpuri", label: "Bhojpuri" },
    { value: "english", label: "English" },
    { value: "instrumental", label: "Instrumental" },
    { value: "other", label: "Other" }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Music className="mr-2 h-5 w-5 text-music-600" />
          Basic Information
        </CardTitle>
        <CardDescription>
          Enter details about your release
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label>Release Type <span className="text-red-500">*</span></Label>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              className={`px-4 py-2 rounded-md border ${releaseInfo.releaseType === 'Single' ? 'bg-music-600 text-white' : 'bg-white'}`}
              onClick={() => handleReleaseTypeChange('Single')}
            >
              Single
            </button>
            <button
              type="button"
              className={`px-4 py-2 rounded-md border ${releaseInfo.releaseType === 'Album' ? 'bg-music-600 text-white' : 'bg-white'}`}
              onClick={() => handleReleaseTypeChange('Album')}
            >
              Album
            </button>
            <button
              type="button"
              className={`px-4 py-2 rounded-md border ${releaseInfo.releaseType === 'EP' ? 'bg-music-600 text-white' : 'bg-white'}`}
              onClick={() => handleReleaseTypeChange('EP')}
            >
              EP
            </button>
          </div>
        </div>
        
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="title">Song Name <span className="text-red-500">*</span></Label>
            <Input 
              id="title" 
              name="title"
              placeholder="Enter song title" 
              value={releaseInfo.title}
              onChange={handleChange}
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="artistId">Artist <span className="text-red-500">*</span></Label>
            <select
              id="artistId"
              name="artistId"
              className="w-full p-2 border rounded-md"
              value={releaseInfo.artistId}
              onChange={handleArtistChange}
            >
              <option value="">Select or create artist...</option>
              {artists.map(artist => (
                <option key={artist.id} value={artist.id}>
                  {artist.name}
                </option>
              ))}
            </select>
            <p className="text-xs text-gray-500 mt-1">
              Create new artists in the Artist Management section
            </p>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="instagramId">Instagram ID</Label>
            <Input 
              id="instagramId" 
              name="instagramId"
              placeholder="e.g. artist_official" 
              value={releaseInfo.instagramId}
              onChange={handleChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="featuredArtists">Featured Artists</Label>
            <Input 
              id="featuredArtists" 
              name="featuredArtists"
              placeholder="e.g. Artist 1, Artist 2" 
              value={releaseInfo.featuredArtists}
              onChange={handleChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="album">Album/EP Title</Label>
            <Input 
              id="album" 
              name="album"
              placeholder="Leave blank for single" 
              value={releaseInfo.album}
              onChange={handleChange}
              disabled={releaseInfo.releaseType === 'Single'}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="labelId">Label <span className="text-red-500">*</span></Label>
            <select
              id="labelId"
              name="labelId"
              className="w-full p-2 border rounded-md"
              value={releaseInfo.labelId}
              onChange={handleLabelChange}
            >
              <option value="">Select or create label...</option>
              {labels.map(label => (
                <option key={label.id} value={label.id}>
                  {label.name}
                </option>
              ))}
              <option value="independent">Independent (No Label)</option>
            </select>
            <p className="text-xs text-gray-500 mt-1">
              Create new labels in the Label Management section
            </p>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="genre">Genre <span className="text-red-500">*</span></Label>
            <Select 
              onValueChange={(value) => handleSelectChange("genre", value)}
              value={releaseInfo.genre}
            >
              <SelectTrigger id="genre">
                <SelectValue placeholder="Select genre" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="pop">Pop</SelectItem>
                <SelectItem value="rock">Rock</SelectItem>
                <SelectItem value="hiphop">Hip Hop/Rap</SelectItem>
                <SelectItem value="rnb">R&B/Soul</SelectItem>
                <SelectItem value="electronic">Electronic/Dance</SelectItem>
                <SelectItem value="bollywood">Bollywood</SelectItem>
                <SelectItem value="folk">Folk/Acoustic</SelectItem>
                <SelectItem value="devotional">Devotional</SelectItem>
                <SelectItem value="classical_indian">Classical Indian</SelectItem>
                <SelectItem value="indie">Indie</SelectItem>
                <SelectItem value="other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="language">Language <span className="text-red-500">*</span></Label>
            <Select 
              onValueChange={(value) => handleSelectChange("language", value)}
              value={releaseInfo.language}
            >
              <SelectTrigger id="language">
                <SelectValue placeholder="Select language" />
              </SelectTrigger>
              <SelectContent>
                {indianLanguages.map(lang => (
                  <SelectItem key={lang.value} value={lang.value}>{lang.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          <div className="flex items-center space-x-2 pt-6">
            <Checkbox 
              id="explicit" 
              checked={releaseInfo.explicit} 
              onCheckedChange={handleExplicitChange}
            />
            <label
              htmlFor="explicit"
              className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
            >
              This release contains explicit content
            </label>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default BasicInformation;
