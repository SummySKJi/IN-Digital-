
import React from 'react';
import { CheckCircle2, Music, Info, Globe } from 'lucide-react';

interface ProgressStepsProps {
  currentStep: number;
}

const ProgressSteps: React.FC<ProgressStepsProps> = ({ currentStep }) => {
  const steps = [
    { 
      id: 1, 
      name: 'Upload Files',
      description: 'Upload your music and artwork',
      icon: Music 
    },
    { 
      id: 2, 
      name: 'Release Info', 
      description: 'Add metadata and credits',
      icon: Info 
    },
    { 
      id: 3, 
      name: 'Distribution', 
      description: 'Choose platforms and territories',
      icon: Globe 
    }
  ];

  return (
    <div className="mb-8">
      <div className="relative">
        {/* Desktop version */}
        <div className="hidden sm:block">
          <div className="flex items-center justify-between">
            {steps.map((step) => (
              <React.Fragment key={step.id}>
                <div className="flex flex-col items-center relative z-10">
                  <div className={`h-12 w-12 rounded-full flex items-center justify-center ${
                    currentStep >= step.id 
                      ? 'bg-music-600 text-white' 
                      : 'bg-gray-200 text-gray-500'
                  } ${
                    currentStep === step.id 
                      ? 'ring-4 ring-music-100' 
                      : ''
                  } transition-all duration-200`}>
                    {currentStep > step.id ? (
                      <CheckCircle2 className="h-6 w-6" />
                    ) : (
                      <step.icon className="h-5 w-5" />
                    )}
                  </div>
                  <div className="mt-3 flex flex-col items-center">
                    <span className="text-sm font-medium">
                      {step.name}
                    </span>
                    <span className="text-xs text-gray-500 mt-1 text-center">
                      {step.description}
                    </span>
                  </div>
                </div>
                
                {step.id < steps.length && (
                  <div className={`flex-1 h-1 mx-2 ${
                    currentStep > step.id ? 'bg-music-600' : 'bg-gray-200'
                  }`}></div>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
        
        {/* Mobile version - more compact */}
        <div className="sm:hidden">
          <div className="flex items-center justify-between">
            {steps.map((step) => (
              <React.Fragment key={step.id}>
                <div className="flex flex-col items-center">
                  <div className={`h-10 w-10 rounded-full flex items-center justify-center ${
                    currentStep >= step.id ? 'bg-music-600 text-white' : 'bg-gray-200 text-gray-400'
                  } ${currentStep === step.id ? 'ring-2 ring-music-100' : ''}`}>
                    {currentStep > step.id ? (
                      <CheckCircle2 className="h-4 w-4" />
                    ) : (
                      <span>{step.id}</span>
                    )}
                  </div>
                  <span className="text-xs mt-1 font-medium">
                    {step.name}
                  </span>
                </div>
                
                {step.id < steps.length && (
                  <div className={`flex-1 h-1 mx-1 ${
                    currentStep > step.id ? 'bg-music-600' : 'bg-gray-200'
                  }`}></div>
                )}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProgressSteps;
