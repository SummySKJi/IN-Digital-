
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Globe } from 'lucide-react';

const TerritorySelection: React.FC = () => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <Globe className="mr-2 h-5 w-5 text-music-600" />
          Territory Selection
        </CardTitle>
        <CardDescription>
          Choose where your music will be available
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          <div className="flex items-center space-x-3">
            <div>
              <input 
                type="radio" 
                id="worldwide" 
                name="territory" 
                className="peer hidden" 
                defaultChecked 
              />
              <label 
                htmlFor="worldwide"
                className="flex items-center space-x-2 p-3 border rounded-lg cursor-pointer 
                  peer-checked:border-music-500 peer-checked:bg-music-50"
              >
                <div className="h-4 w-4 rounded-full border border-gray-300 flex items-center justify-center peer-checked:border-music-500">
                  <div className="h-2 w-2 rounded-full peer-checked:bg-music-500"></div>
                </div>
                <div>
                  <h3 className="font-medium">Worldwide Distribution</h3>
                  <p className="text-xs text-gray-500">Release your music in all available territories</p>
                </div>
              </label>
            </div>
          </div>
          
          <div className="flex items-center space-x-3">
            <div>
              <input 
                type="radio" 
                id="custom-territories" 
                name="territory" 
                className="peer hidden"
              />
              <label 
                htmlFor="custom-territories"
                className="flex items-center space-x-2 p-3 border rounded-lg cursor-pointer 
                  peer-checked:border-music-500 peer-checked:bg-music-50"
              >
                <div className="h-4 w-4 rounded-full border border-gray-300 flex items-center justify-center peer-checked:border-music-500">
                  <div className="h-2 w-2 rounded-full peer-checked:bg-music-500"></div>
                </div>
                <div>
                  <h3 className="font-medium">Custom Territory Selection</h3>
                  <p className="text-xs text-gray-500">Choose specific countries for distribution</p>
                </div>
              </label>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default TerritorySelection;
