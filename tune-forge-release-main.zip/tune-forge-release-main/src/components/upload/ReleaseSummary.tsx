
import React from 'react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";  // Updated import
import { Music, Globe, Mic, Tag, FileMusic } from 'lucide-react';

interface ReleaseSummaryProps {
  releaseInfo: {
    title: string;
    primaryArtist: string;
    featuredArtists: string;
    composer?: string;
    producer?: string;
    album?: string;
    genre?: string;
    language?: string;
    explicit?: boolean;
    copyright?: string;
    label?: string;
  };
  coverImageUrl: string | null;
  selectedPlatforms?: string[];
}

const ReleaseSummary: React.FC<ReleaseSummaryProps> = ({ 
  releaseInfo, 
  coverImageUrl,
  selectedPlatforms 
}) => {
  return (
    <Card className="overflow-hidden">
      <CardHeader className="bg-music-50">
        <CardTitle className="flex items-center">
          <Music className="mr-2 h-5 w-5 text-music-600" />
          Release Summary
        </CardTitle>
        <CardDescription>Preview of your music release</CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <div className="flex flex-col md:flex-row gap-6">
          {/* Cover Art */}
          <div className="w-full md:w-1/3 flex-shrink-0">
            {coverImageUrl ? (
              <img 
                src={coverImageUrl} 
                alt="Cover Art" 
                className="w-full aspect-square object-cover rounded-lg shadow-md border border-gray-200"
              />
            ) : (
              <div className="w-full aspect-square bg-gray-100 rounded-lg flex items-center justify-center border border-gray-200">
                <FileMusic className="h-16 w-16 text-gray-400" />
              </div>
            )}
          </div>
          
          {/* Release Information */}
          <div className="w-full md:w-2/3 space-y-4">
            <div>
              <h2 className="text-2xl font-bold text-gray-900">{releaseInfo.title || "Untitled Track"}</h2>
              <div className="flex items-center mt-1 text-lg text-gray-600">
                <Mic className="mr-1 h-4 w-4" />
                <span>{releaseInfo.primaryArtist || "Unknown Artist"}</span>
              </div>
              
              {releaseInfo.featuredArtists && (
                <p className="text-sm text-gray-600 mt-1">feat. {releaseInfo.featuredArtists}</p>
              )}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-x-4 gap-y-2 mt-4">
              {releaseInfo.label && (
                <div className="flex items-center text-sm">
                  <span className="font-medium text-gray-700 mr-2">Label:</span>
                  <span>{releaseInfo.label}</span>
                </div>
              )}
              
              {releaseInfo.genre && (
                <div className="flex items-center text-sm">
                  <span className="font-medium text-gray-700 mr-2">Genre:</span>
                  <span>{releaseInfo.genre}</span>
                </div>
              )}
              
              {releaseInfo.language && (
                <div className="flex items-center text-sm">
                  <Globe className="mr-1 h-3 w-3 text-gray-500" />
                  <span className="font-medium text-gray-700 mr-2">Language:</span>
                  <span>{releaseInfo.language}</span>
                </div>
              )}
              
              {releaseInfo.composer && (
                <div className="flex items-center text-sm">
                  <span className="font-medium text-gray-700 mr-2">Composer:</span>
                  <span>{releaseInfo.composer}</span>
                </div>
              )}
              
              {releaseInfo.producer && (
                <div className="flex items-center text-sm">
                  <span className="font-medium text-gray-700 mr-2">Producer:</span>
                  <span>{releaseInfo.producer}</span>
                </div>
              )}
              
              {releaseInfo.copyright && (
                <div className="flex items-center text-sm">
                  <span className="font-medium text-gray-700 mr-2">©:</span>
                  <span>{releaseInfo.copyright}</span>
                </div>
              )}
              
              {releaseInfo.explicit !== undefined && (
                <div className="flex items-center text-sm">
                  <span className="font-medium text-gray-700 mr-2">Content:</span>
                  <span className={`px-2 py-0.5 rounded text-xs ${
                    releaseInfo.explicit 
                      ? 'bg-red-100 text-red-800' 
                      : 'bg-green-100 text-green-800'
                  }`}>
                    {releaseInfo.explicit ? 'Explicit' : 'Clean'}
                  </span>
                </div>
              )}
            </div>
            
            {/* Distribution Platforms */}
            {selectedPlatforms && selectedPlatforms.length > 0 && (
              <div className="mt-5">
                <p className="text-sm font-medium text-gray-700 mb-2">
                  <Tag className="inline mr-1 h-3 w-3" />
                  Distribution Platforms:
                </p>
                <div className="flex flex-wrap gap-2">
                  {selectedPlatforms.map((platform, index) => (
                    <Badge key={index} className="bg-music-100 text-music-800 hover:bg-music-200">
                      {platform}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ReleaseSummary;
