
import React from 'react';
import { Card, CardHeader, CardTitle, CardDescription, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { TooltipProvider, Tooltip, TooltipTrigger, TooltipContent } from "@/components/ui/tooltip";
import { FileText, Info } from 'lucide-react';

interface ReleaseInfoType {
  title: string;
  primaryArtist: string;
  featuredArtists: string;
  composer: string;
  producer: string;
  album: string;
  genre: string;
  language: string;
  explicit: boolean;
  copyright: string;
  label: string;
  upc: string;
  isrc: string;
  notes: string;
}

interface CreditsMetadataProps {
  releaseInfo: ReleaseInfoType;
  handleChange: (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => void;
}

const CreditsMetadata: React.FC<CreditsMetadataProps> = ({ releaseInfo, handleChange }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <FileText className="mr-2 h-5 w-5 text-music-600" />
          Credits & Metadata
        </CardTitle>
        <CardDescription>
          Enter songwriter, producer, and legal information
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="composer">Songwriter/Composer</Label>
            <Input 
              id="composer" 
              name="composer"
              placeholder="Who wrote the song" 
              value={releaseInfo.composer}
              onChange={handleChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="producer">Producer</Label>
            <Input 
              id="producer" 
              name="producer"
              placeholder="Who produced the track" 
              value={releaseInfo.producer}
              onChange={handleChange}
            />
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center">
              <Label htmlFor="isrc">ISRC Code</Label>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-4 w-4 text-gray-400 ml-1" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="w-80 text-xs">
                      International Standard Recording Code - A unique identifier for your recording. 
                      Leave blank and we'll generate one for you.
                    </p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <Input 
              id="isrc" 
              name="isrc"
              placeholder="e.g. US-ABC-12-34567 (leave blank to generate)" 
              value={releaseInfo.isrc}
              onChange={handleChange}
            />
          </div>
          
          <div className="space-y-2">
            <div className="flex items-center">
              <Label htmlFor="upc">UPC/EAN Code</Label>
              <TooltipProvider>
                <Tooltip>
                  <TooltipTrigger asChild>
                    <Info className="h-4 w-4 text-gray-400 ml-1" />
                  </TooltipTrigger>
                  <TooltipContent>
                    <p className="w-80 text-xs">
                      Universal Product Code - Identifies your entire release. 
                      Leave blank and we'll generate one for you.
                    </p>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            </div>
            <Input 
              id="upc" 
              name="upc"
              placeholder="e.g. 123456789012 (leave blank to generate)" 
              value={releaseInfo.upc}
              onChange={handleChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="copyright">Copyright ©</Label>
            <Input 
              id="copyright" 
              name="copyright"
              placeholder="e.g. 2023 Your Label" 
              value={releaseInfo.copyright}
              onChange={handleChange}
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="label">Label Name</Label>
            <Input 
              id="label" 
              name="label"
              placeholder="Your label name (or 'Independent')" 
              value={releaseInfo.label}
              onChange={handleChange}
            />
          </div>
        </div>
        
        <div className="pt-2">
          <Label htmlFor="notes">Additional Notes</Label>
          <Textarea 
            id="notes" 
            name="notes"
            placeholder="Any important details we should know about this release" 
            className="h-24 mt-2"
            value={releaseInfo.notes}
            onChange={handleChange}
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default CreditsMetadata;
