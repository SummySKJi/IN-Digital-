
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { 
  Home, 
  Music, 
  Upload, 
  BarChart, 
  DollarSign, 
  Settings, 
  HelpCircle,
  ChevronRight,
  Users
} from 'lucide-react';

interface MobileSidebarProps {
  isOpen: boolean;
  onClose: () => void;
}

const MobileSidebar: React.FC<MobileSidebarProps> = ({ isOpen, onClose }) => {
  const location = useLocation();

  const navItems = [
    { icon: Home, label: 'Dashboard', path: '/dashboard' },
    { icon: Music, label: 'My Catalog', path: '/dashboard/releases' },
    { icon: Upload, label: 'Upload Music', path: '/dashboard/upload' },
    { icon: BarChart, label: 'Analytics', path: '/dashboard/analytics' },
    { icon: DollarSign, label: 'Wallet', path: '/dashboard/wallet' },
    { icon: Users, label: 'Artist & Label', path: '/dashboard/artist-management' },
    { icon: Music, label: 'Official Artist Channel', path: '/dashboard/official-artist-channel' },
    { icon: Settings, label: 'Settings', path: '/dashboard/settings' },
    { icon: HelpCircle, label: 'Help & Support', path: '/dashboard/support' },
  ];

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm">
      <div className="fixed inset-y-0 right-0 w-full max-w-xs bg-white shadow-xl animate-in slide-in-from-right">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="text-lg font-semibold">Menu</h2>
          <Button variant="ghost" size="icon" onClick={onClose} className="h-8 w-8">
            <X className="h-4 w-4" />
          </Button>
        </div>
        <nav className="p-4">
          <div className="space-y-1">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center px-4 py-3 text-sm font-medium rounded-md transition-colors ${
                  isActive(item.path)
                    ? 'bg-music-50 text-music-700'
                    : 'text-gray-700 hover:bg-gray-100'
                }`}
                onClick={onClose}
              >
                <item.icon className={`h-5 w-5 mr-3 ${isActive(item.path) ? 'text-music-700' : 'text-gray-500'}`} />
                {item.label}
                {isActive(item.path) && <ChevronRight className="ml-auto h-4 w-4" />}
              </Link>
            ))}
          </div>
        </nav>
      </div>
    </div>
  );
};

export default MobileSidebar;
