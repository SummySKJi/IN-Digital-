
import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { 
  Home, 
  Music, 
  Upload, 
  BarChart, 
  DollarSign, 
  Settings, 
  HelpCircle,
  ChevronRight,
  Users
} from 'lucide-react';

interface SidebarProps {
  isMobile: boolean;
  mobileMenuOpen: boolean;
  toggleMobileMenu: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ isMobile, mobileMenuOpen, toggleMobileMenu }) => {
  const location = useLocation();

  const navItems = [
    { icon: Home, label: 'Dashboard', path: '/dashboard' },
    { icon: Music, label: 'My Catalog', path: '/dashboard/releases' },
    { icon: Upload, label: 'Upload Music', path: '/dashboard/upload' },
    { icon: BarChart, label: 'Analytics', path: '/dashboard/analytics' },
    { icon: DollarSign, label: 'Wallet', path: '/dashboard/wallet' },
    { icon: Users, label: 'Artist & Label', path: '/dashboard/artist-management' },
    { icon: Music, label: 'Official Artist Channel', path: '/dashboard/official-artist-channel' },
    { icon: Settings, label: 'Settings', path: '/dashboard/settings' },
    { icon: HelpCircle, label: 'Help & Support', path: '/dashboard/support' },
  ];

  const isActive = (path: string) => {
    return location.pathname === path;
  };

  // Render the desktop sidebar
  const renderDesktopSidebar = () => (
    <aside className="hidden md:block w-64 bg-white border-r border-gray-200 h-[calc(100vh-57px)] fixed">
      <nav className="py-4 px-3">
        <div className="space-y-1">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center px-4 py-2.5 text-sm font-medium rounded-md transition-colors ${
                isActive(item.path)
                  ? 'bg-music-50 text-music-700'
                  : 'text-gray-700 hover:bg-gray-100'
              }`}
            >
              <item.icon className={`h-5 w-5 mr-3 ${isActive(item.path) ? 'text-music-700' : 'text-gray-500'}`} />
              {item.label}
              {isActive(item.path) && <ChevronRight className="ml-auto h-4 w-4" />}
            </Link>
          ))}
        </div>
      </nav>
    </aside>
  );

  return (
    <>
      {renderDesktopSidebar()}
    </>
  );
};

export default Sidebar;
