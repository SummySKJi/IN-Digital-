
import React from 'react';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { Menu, Music } from 'lucide-react';

interface HeaderProps {
  isMobile: boolean;
  toggleMobileMenu: () => void;
}

const Header: React.FC<HeaderProps> = ({ isMobile, toggleMobileMenu }) => {
  return (
    <header className="h-14 border-b bg-white p-3 flex items-center sticky top-0 z-40">
      <div className="flex items-center gap-3 md:hidden">
        <Button 
          variant="ghost" 
          size="icon" 
          onClick={toggleMobileMenu}
          className="md:hidden"
        >
          <Menu className="h-5 w-5" />
          <span className="sr-only">Toggle menu</span>
        </Button>
      </div>
      
      <div className="flex items-center gap-2">
        <Music className="h-5 w-5 text-music-600" />
        <span className="font-semibold">TuneForge</span>
      </div>
      
      <div className="ml-auto flex items-center gap-4">
        <Avatar className="h-8 w-8">
          <AvatarImage src="https://github.com/shadcn.png" alt="User" />
          <AvatarFallback>JD</AvatarFallback>
        </Avatar>
      </div>
    </header>
  );
};

export default Header;
