
export interface Artist {
  id: string;
  user_id: string;
  name: string;
  email: string;
  phone: string;
  whatsapp?: string;
  website?: string;
  gender: string;
  youtube_channel?: string;
  instagram_id?: string;
  facebook_page?: string;
  bio?: string;
  spotify_profile?: string;
  apple_music_profile?: string;
  country: string;
  genres: string[];
  languages: string[];
  created_at?: string;
  updated_at?: string;
}

export interface Label {
  id: string;
  user_id: string;
  name: string;
  email?: string;
  phone?: string;
  whatsapp?: string;
  website?: string;
  youtube_channel?: string;
  instagram_id?: string;
  facebook_page?: string;
  bio?: string;
  country: string;
  genres: string[];
  languages: string[];
  created_at?: string;
  updated_at?: string;
}

export interface OfficialArtistChannelRequest {
  id: string;
  user_id: string;
  artist_id: string;
  youtube_channel_link: string;
  topic_channel_link?: string;
  status: 'pending' | 'approved' | 'rejected';
  admin_notes?: string;
  created_at?: string;
  updated_at?: string;
  artist_name?: string;
}

export interface WithdrawalRequest {
  id: string;
  user_id: string;
  amount: number;
  payment_method: string;
  account_details: Record<string, any>;
  status: 'pending' | 'approved' | 'rejected';
  created_at?: string;
  updated_at?: string;
}

export interface MusicSubmission {
  id: string;
  user_id: string;
  type: 'Single' | 'Album' | 'EP';
  song_name: string;
  artist_name: string;
  artist_id?: string;
  instagram_id?: string;
  lyricists: string;
  music_producer?: string;
  copyright: string;
  publisher?: string;
  song_language: string;
  label_name: string;
  label_id?: string;
  platforms: string[];
  status: 'pending' | 'approved' | 'rejected' | 'processing' | 'released';
  rejection_reason?: string;
  audio_file_name: string;
  cover_art_file_name: string;
  file_size: string;
  submitted_date: string;
  upload_progress?: number;
}
