export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  public: {
    Tables: {
      artists: {
        Row: {
          apple_music_profile: string | null
          bio: string | null
          country: string | null
          created_at: string | null
          email: string
          facebook_page: string | null
          gender: string | null
          genres: string[] | null
          id: string
          instagram_id: string | null
          languages: string[] | null
          name: string
          phone: string
          spotify_profile: string | null
          updated_at: string | null
          user_id: string
          website: string | null
          whatsapp: string | null
          youtube_channel: string | null
        }
        Insert: {
          apple_music_profile?: string | null
          bio?: string | null
          country?: string | null
          created_at?: string | null
          email: string
          facebook_page?: string | null
          gender?: string | null
          genres?: string[] | null
          id?: string
          instagram_id?: string | null
          languages?: string[] | null
          name: string
          phone: string
          spotify_profile?: string | null
          updated_at?: string | null
          user_id: string
          website?: string | null
          whatsapp?: string | null
          youtube_channel?: string | null
        }
        Update: {
          apple_music_profile?: string | null
          bio?: string | null
          country?: string | null
          created_at?: string | null
          email?: string
          facebook_page?: string | null
          gender?: string | null
          genres?: string[] | null
          id?: string
          instagram_id?: string | null
          languages?: string[] | null
          name?: string
          phone?: string
          spotify_profile?: string | null
          updated_at?: string | null
          user_id?: string
          website?: string | null
          whatsapp?: string | null
          youtube_channel?: string | null
        }
        Relationships: []
      }
      labels: {
        Row: {
          bio: string | null
          country: string | null
          created_at: string | null
          email: string | null
          facebook_page: string | null
          genres: string[] | null
          id: string
          instagram_id: string | null
          languages: string[] | null
          name: string
          phone: string | null
          updated_at: string | null
          user_id: string
          website: string | null
          whatsapp: string | null
          youtube_channel: string | null
        }
        Insert: {
          bio?: string | null
          country?: string | null
          created_at?: string | null
          email?: string | null
          facebook_page?: string | null
          genres?: string[] | null
          id?: string
          instagram_id?: string | null
          languages?: string[] | null
          name: string
          phone?: string | null
          updated_at?: string | null
          user_id: string
          website?: string | null
          whatsapp?: string | null
          youtube_channel?: string | null
        }
        Update: {
          bio?: string | null
          country?: string | null
          created_at?: string | null
          email?: string | null
          facebook_page?: string | null
          genres?: string[] | null
          id?: string
          instagram_id?: string | null
          languages?: string[] | null
          name?: string
          phone?: string | null
          updated_at?: string | null
          user_id?: string
          website?: string | null
          whatsapp?: string | null
          youtube_channel?: string | null
        }
        Relationships: []
      }
      music_submissions: {
        Row: {
          artist_name: string
          audio_file_name: string
          copyright: string
          cover_art_file_name: string
          file_size: string
          id: string
          instagram_id: string | null
          label_name: string
          lyricists: string
          music_producer: string | null
          platforms: string[]
          publisher: string | null
          song_language: string
          song_name: string
          status: string
          submitted_date: string
          type: string
          user_id: string
        }
        Insert: {
          artist_name: string
          audio_file_name: string
          copyright: string
          cover_art_file_name: string
          file_size: string
          id?: string
          instagram_id?: string | null
          label_name: string
          lyricists: string
          music_producer?: string | null
          platforms: string[]
          publisher?: string | null
          song_language: string
          song_name: string
          status?: string
          submitted_date?: string
          type: string
          user_id: string
        }
        Update: {
          artist_name?: string
          audio_file_name?: string
          copyright?: string
          cover_art_file_name?: string
          file_size?: string
          id?: string
          instagram_id?: string | null
          label_name?: string
          lyricists?: string
          music_producer?: string | null
          platforms?: string[]
          publisher?: string | null
          song_language?: string
          song_name?: string
          status?: string
          submitted_date?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      official_artist_channel_requests: {
        Row: {
          admin_notes: string | null
          artist_id: string
          created_at: string | null
          id: string
          status: string
          topic_channel_link: string | null
          updated_at: string | null
          user_id: string
          youtube_channel_link: string
        }
        Insert: {
          admin_notes?: string | null
          artist_id: string
          created_at?: string | null
          id?: string
          status?: string
          topic_channel_link?: string | null
          updated_at?: string | null
          user_id: string
          youtube_channel_link: string
        }
        Update: {
          admin_notes?: string | null
          artist_id?: string
          created_at?: string | null
          id?: string
          status?: string
          topic_channel_link?: string | null
          updated_at?: string | null
          user_id?: string
          youtube_channel_link?: string
        }
        Relationships: [
          {
            foreignKeyName: "official_artist_channel_requests_artist_id_fkey"
            columns: ["artist_id"]
            isOneToOne: false
            referencedRelation: "artists"
            referencedColumns: ["id"]
          },
        ]
      }
      withdrawal_requests: {
        Row: {
          account_details: Json
          amount: number
          created_at: string | null
          id: string
          payment_method: string
          status: string
          updated_at: string | null
          user_id: string
        }
        Insert: {
          account_details: Json
          amount: number
          created_at?: string | null
          id?: string
          payment_method: string
          status?: string
          updated_at?: string | null
          user_id: string
        }
        Update: {
          account_details?: Json
          amount?: number
          created_at?: string | null
          id?: string
          payment_method?: string
          status?: string
          updated_at?: string | null
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DefaultSchema = Database[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? (Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      Database[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof Database },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof Database },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends { schema: keyof Database }
  ? Database[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof Database },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof Database
  }
    ? keyof Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends { schema: keyof Database }
  ? Database[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {},
  },
} as const
