
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Index from "./pages/Index";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";
import Register from "./pages/Register";
import AdminLogin from "./pages/AdminLogin";
import Dashboard from "./pages/Dashboard";
import UploadMusic from "./pages/UploadMusic";
import AdminDashboard from "./pages/AdminDashboard";
import DashboardLayout from "./components/layout/DashboardLayout";
import MyReleases from "./pages/MyReleases";
import Analytics from "./pages/Analytics";
import Wallet from "./pages/Wallet";
import OfficialArtistChannel from "./pages/OfficialArtistChannel";
import ArtistManagement from "./pages/ArtistManagement";
import AdminReleaseReview from "./pages/AdminReleaseReview";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner />
      <BrowserRouter>
        <Routes>
          {/* Public Routes */}
          <Route path="/" element={<Index />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route path="/admin-login" element={<AdminLogin />} />
          
          {/* Dashboard Routes */}
          <Route path="/dashboard" element={<DashboardLayout />}>
            <Route index element={<Dashboard />} />
            <Route path="upload" element={<UploadMusic />} />
            <Route path="releases" element={<MyReleases />} />
            <Route path="analytics" element={<Analytics />} />
            <Route path="wallet" element={<Wallet />} />
            <Route path="official-artist-channel" element={<OfficialArtistChannel />} />
            <Route path="artist-management" element={<ArtistManagement />} />
            {/* Add other dashboard routes as needed */}
          </Route>
          
          {/* Admin Routes */}
          <Route path="/admin-dashboard" element={<AdminDashboard />} />
          <Route path="/admin-dashboard/review/:id" element={<AdminReleaseReview />} />
          
          {/* 404 Route */}
          <Route path="*" element={<NotFound />} />
        </Routes>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
