
import { useState } from 'react';
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

export interface ReleaseInfo {
  title: string;
  primaryArtist: string;
  artistId: string;
  featuredArtists: string;
  composer: string;
  producer: string;
  album: string;
  releaseType: string;
  genre: string;
  language: string;
  explicit: boolean;
  copyright: string;
  label: string;
  labelId: string;
  upc: string;
  isrc: string;
  notes: string;
  instagramId: string;
  publisher: string;
}

export const useUploadMusicForm = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [uploadedFile, setUploadedFile] = useState<File | null>(null);
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [coverImage, setCoverImage] = useState<File | null>(null);
  const [coverImageUrl, setCoverImageUrl] = useState<string | null>(null);
  const [releaseDate, setReleaseDate] = useState<Date | undefined>(undefined);
  const [selectedPlatforms, setSelectedPlatforms] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [releaseInfo, setReleaseInfo] = useState<ReleaseInfo>({
    title: '',
    primaryArtist: '',
    artistId: '',
    featuredArtists: '',
    composer: '',
    producer: '',
    album: '',
    releaseType: 'Single',
    genre: '',
    language: '',
    explicit: false,
    copyright: '',
    label: '',
    labelId: '',
    upc: '',
    isrc: '',
    notes: '',
    instagramId: '',
    publisher: '',
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setReleaseInfo(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setReleaseInfo(prev => ({ ...prev, [name]: value }));
  };

  const handleExplicitChange = (checked: boolean) => {
    setReleaseInfo(prev => ({ ...prev, explicit: checked }));
  };

  const nextStep = () => {
    if (currentStep < 3) {
      setCurrentStep(currentStep + 1);
      window.scrollTo(0, 0);
    }
  };

  const prevStep = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
      window.scrollTo(0, 0);
    }
  };

  const finalizeSubmission = async (userId: string) => {
    try {
      const audio_file_name = uploadedFile!.name;
      const cover_art_file_name = coverImage!.name;
      const file_size = `${(uploadedFile!.size / (1024 * 1024)).toFixed(2)} MB`;

      const { error } = await supabase
        .from("music_submissions")
        .insert([{
          user_id: userId,
          artist_id: releaseInfo.artistId || null,
          artist_name: releaseInfo.primaryArtist,
          audio_file_name,
          copyright: releaseInfo.copyright,
          cover_art_file_name,
          file_size,
          instagram_id: releaseInfo.instagramId,
          label_id: releaseInfo.labelId || null,
          label_name: releaseInfo.label || "Independent",
          lyricists: releaseInfo.composer,
          music_producer: releaseInfo.producer,
          platforms: selectedPlatforms.length > 0 ? selectedPlatforms : ["Spotify", "Apple Music", "YouTube Music"],
          publisher: releaseInfo.publisher,
          song_language: releaseInfo.language,
          song_name: releaseInfo.title,
          status: "pending",
          submitted_date: new Date().toISOString(),
          type: releaseInfo.releaseType,
        }]);

      if (error) {
        throw error;
      }

      toast.success("Your music has been submitted for distribution!");
      resetForm();
    } catch (err) {
      toast.error("Upload failed during finalization.");
    } finally {
      setIsSubmitting(false);
      setUploadProgress(0);
    }
  };

  const resetForm = () => {
    setCurrentStep(1);
    setUploadedFile(null);
    setUploadProgress(0);
    setCoverImage(null);
    setCoverImageUrl(null);
    setSelectedPlatforms([]);
    setReleaseInfo({
      title: '',
      primaryArtist: '',
      artistId: '',
      featuredArtists: '',
      composer: '',
      producer: '',
      album: '',
      releaseType: 'Single',
      genre: '',
      language: '',
      explicit: false,
      copyright: '',
      label: '',
      labelId: '',
      upc: '',
      isrc: '',
      notes: '',
      instagramId: '',
      publisher: '',
    });
  };

  const handleSubmit = async () => {
    if (!uploadedFile || !coverImage) {
      toast.error("Please upload both audio file and cover image.");
      return;
    }
    setIsSubmitting(true);

    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const user = sessionData.session?.user;
      if (!user) {
        toast.error("You must be logged in to upload music.");
        setIsSubmitting(false);
        return;
      }

      const simulateUpload = () => {
        let progress = 0;
        const interval = setInterval(() => {
          progress += 5;
          setUploadProgress(progress);
          if (progress >= 100) {
            clearInterval(interval);
            finalizeSubmission(user.id);
          }
        }, 200);
      };

      simulateUpload();
    } catch (err) {
      toast.error("Upload failed.");
      setIsSubmitting(false);
      setUploadProgress(0);
    }
  };

  return {
    currentStep,
    uploadedFile,
    uploadProgress,
    coverImage,
    coverImageUrl,
    releaseDate,
    selectedPlatforms,
    isSubmitting,
    releaseInfo,
    setUploadedFile,
    setCoverImage,
    setCoverImageUrl,
    setReleaseDate,
    setSelectedPlatforms,
    handleChange,
    handleSelectChange,
    handleExplicitChange,
    nextStep,
    prevStep,
    handleSubmit
  };
};

